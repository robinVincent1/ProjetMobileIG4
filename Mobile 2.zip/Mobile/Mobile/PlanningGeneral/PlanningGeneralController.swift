import UIKit
import CalendarKit
import SwiftUI

final class PlanningGeneralController: DayViewController {
    var data = [["Breakfast at Tiffany's",
                 "New York, 5th avenue"],

                ["Workout",
                 "Tufteparken"],

                ["Meeting with Alex",
                 "Home",
                 "Oslo, Tjuvholmen"],

                ["Beach Volleyball",
                 "Ipanema Beach",
                 "Rio De Janeiro"],

                ["WWDC",
                 "Moscone West Convention Center",
                 "747 Howard St"],

                ["Google I/O",
                 "Shoreline Amphitheatre",
                 "One Amphitheatre Parkway"],

                ["✈️️ to Svalbard ❄️️❄️️❄️️❤️️",
                 "Oslo Gardermoen"],

                ["💻📲 Developing CalendarKit",
                 "🌍 Worldwide"],

                ["Software Development Lecture",
                 "Mikpoli MB310",
                 "Craig Federighi"],

    ]
    
    var creneau : [Creneau] = []
    
    func fetchCreneauxAndUpdateList(date: Date) -> [EventDescriptor]? {
        var errorMessage = "" // Réinitialiser le message d'erreur
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // Le format que vous souhaitez pour la date
        let dateString = dateFormatter.string(from: date)
        print("\(dateString)")

        // Appeler la fonction pour récupérer les créneaux depuis l'API
        if let creneaux = getCreneauxFromAPI(url: "\(urlAPI)/creneau/getbydate/\(dateString)") {
            var eventDescriptors: [EventDescriptor] = []
            // Parcourir la liste de créneaux et créer un EventDescriptor pour chaque créneau
            for creneau in creneaux {
                let eventDescriptor = generateEventFromCreneau(creneau)
                eventDescriptors.append(eventDescriptor)
            }
            return eventDescriptors
        } else {
            // Gérer l'erreur si la récupération des créneaux échoue
            print("Failed to fetch creneaux")
            return nil
        }
    }


    override func dayView(dayView: DayView, didLongPressTimelineAt date: Date) {
        print("Did long press timeline at date \(date)")
        // Cancel editing current event and start creating a new one
        endEventEditing()
        
        // Call fetchCreneauxAndUpdateList asynchronously
        if let eventDescriptors = fetchCreneauxAndUpdateList(date: date) {
            // Once fetchCreneauxAndUpdateList completes and returns the event descriptors, create the events
            for eventDescriptor in eventDescriptors {
                print("Creating a new event")
                self.create(event: eventDescriptor, animated: true)
            }
        } else {
            // Handle the case where fetching creneaux fails
            print("Failed to fetch creneaux")
        }
    }








    var generatedEvents = [EventDescriptor]()
    var alreadyGeneratedSet = Set<Date>()

    var colors = [UIColor.blue,
                  UIColor.yellow,
                  UIColor.green,
                  UIColor.red]

    private lazy var dateIntervalFormatter: DateIntervalFormatter = {
        let dateIntervalFormatter = DateIntervalFormatter()
        dateIntervalFormatter.dateStyle = .none
        dateIntervalFormatter.timeStyle = .short

        return dateIntervalFormatter
    }()

    override func loadView() {
        calendar.timeZone = TimeZone(identifier: "Europe/Paris")!

        dayView = DayView(calendar: calendar)
        view = dayView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "CalendarKit Demo"
        navigationController?.navigationBar.isTranslucent = false
        dayView.autoScrollToFirstEvent = true
        reloadData()
    }

    // MARK: EventDataSource

    override func eventsForDate(_ date: Date) -> [EventDescriptor] {
        if let eventDescriptors = fetchCreneauxAndUpdateList(date: date) {
            // Once fetchCreneauxAndUpdateList completes and returns the event descriptors, return the events
            print("1")
            return eventDescriptors
        } else {
            // Handle the case where fetching creneaux fails
            print("Failed to fetch creneaux")
            return []
        }
    }


    private func generateEventsForDate(_ date: Date) -> [EventDescriptor] {
        var workingDate = Calendar.current.date(byAdding: .hour, value: Int.random(in: 1...15), to: date)!
        var events = [Event]()

        for i in 0...4 {
            let event = Event()

            let duration = Int.random(in: 60 ... 160)
            event.dateInterval = DateInterval(start: workingDate, duration: TimeInterval(duration * 60))

            var info = data.randomElement() ?? []

            let timezone = dayView.calendar.timeZone
            print(timezone)

            info.append(dateIntervalFormatter.string(from: event.dateInterval.start, to: event.dateInterval.end))
            event.text = info.reduce("", {$0 + $1 + "\n"})
            event.color = colors.randomElement() ?? .red
            event.isAllDay = Bool.random()
            event.lineBreakMode = .byTruncatingTail

            events.append(event)

            let nextOffset = Int.random(in: 40 ... 250)
            workingDate = Calendar.current.date(byAdding: .minute, value: nextOffset, to: workingDate)!
            event.userInfo = String(i)
        }

        print("Events for \(date)")
        return events
    }

    // MARK: DayViewDelegate

    private var createdEvent: EventDescriptor?
    
    //ouverture view modale
    override func dayViewDidSelectEventView(_ eventView: EventView) {
        guard let descriptor = eventView.descriptor as? Event else {
            return
        }
      
        print("Event has been selected: \(descriptor) \(String(describing: descriptor.userInfo))")

        // Vérification et conversion de descriptor.userInfo en Int
        if let id = descriptor.userInfo as? Int {
            let swiftUIView = CreneauView(id: id)
            let hostingController = UIHostingController(rootView: swiftUIView)
            self.present(hostingController, animated: true, completion: nil)
        } else {
            print("Le userInfo n'est pas de type Int.")
        }
    }


    override func dayViewDidLongPressEventView(_ eventView: EventView) {
        guard let descriptor = eventView.descriptor as? Event else {
            return
        }
        endEventEditing()
        print("Event has been longPressed: \(descriptor) \(String(describing: descriptor.userInfo))")
        beginEditing(event: descriptor, animated: true)
        print(Date())
    }

    override func dayView(dayView: DayView, didTapTimelineAt date: Date) {
        endEventEditing()
        print("Did Tap at date: \(date)")
    }

    override func dayViewDidBeginDragging(dayView: DayView) {
        endEventEditing()
        print("DayView did begin dragging")
    }

    override func dayView(dayView: DayView, willMoveTo date: Date) {
        print("DayView = \(dayView) will move to: \(date)")
    }

    override func dayView(dayView: DayView, didMoveTo date: Date) {
        print("DayView = \(dayView) did move to: \(date)")
    }


    private func generateEventNearDate(_ date: Date) -> EventDescriptor {
        let duration = (60...220).randomElement()!
        let startDate = Calendar.current.date(byAdding: .minute, value: -Int(Double(duration) / 2), to: date)!
        let event = Event()

        event.dateInterval = DateInterval(start: startDate, duration: TimeInterval(duration * 60))

        var info = data.randomElement()!

        info.append(dateIntervalFormatter.string(from: event.dateInterval)!)
        event.text = info.reduce("", {$0 + $1 + "\n"})
        event.color = colors.randomElement()!
        event.editedEvent = event

        return event
    }
    
    private func generateEventFromCreneau(_ creneau: Creneau) -> EventDescriptor {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
    
        let dateString = "\(creneau.date.prefix(4))/\(creneau.date.prefix(7).suffix(2))/\(creneau.date.suffix(2)) \(creneau.heure_debut):00"
        let startDate = formatter.date(from: dateString)

        
        // Convertir les heures de début et de fin en minutes
        let heureDebutMinutes = creneau.heure_debut * 60
        let heureFinMinutes = creneau.heure_fin * 60
        
        // Calculer la durée de l'événement en minutes
        let duration = heureFinMinutes - heureDebutMinutes
        
        // Calculer la date de fin en ajoutant la durée à la date de début
        let endDate = Calendar.current.date(byAdding: .minute, value: duration, to: startDate!)!
        
        var event = Event()
        event.dateInterval = DateInterval(start: startDate!, end: endDate) // Intervalle de temps de l'événement
        event.text = creneau.titre ?? "Titre de l'événement" // Titre de l'événement
        event.color = .blue // Couleur de l'événement, vous pouvez définir la couleur appropriée
        event.userInfo = creneau.idCreneau
        
        // Construction de la description de l'événement en utilisant les informations du créneau
        var eventInfo = ""
        eventInfo += "Heure de début : \(creneau.heure_debut):00\n" // Convertir les heures en format hh:mm
        eventInfo += "Heure de fin : \(creneau.heure_fin):00\n" // Convertir les heures en format hh:mm
        eventInfo += "Nombre maximum : \(creneau.nb_max)\n"
        eventInfo += "Nombre inscrit : \(creneau.nb_inscrit)\n"
        
        eventInfo += "ID : \(creneau.idCreneau)" // Ajoutez d'autres informations du créneau selon vos besoins
        
        event.text = eventInfo // Mettez à jour le texte de l'événement avec les informations du créneau
        
        return event
    }



    override func dayView(dayView: DayView, didUpdate event: EventDescriptor) {
        print("did finish editing \(event)")
        print("new startDate: \(event.dateInterval.start) new endDate: \(event.dateInterval.end)")

        if let _ = event.editedEvent {
            event.commitEditing()
        }

        if let createdEvent = createdEvent {
            createdEvent.editedEvent = nil
            generatedEvents.append(createdEvent)
            self.createdEvent = nil
            endEventEditing()
        }

        reloadData()
    }
}
