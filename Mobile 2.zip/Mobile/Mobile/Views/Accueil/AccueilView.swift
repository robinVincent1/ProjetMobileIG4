import SwiftUI

struct AccueilView: View {
    
    
    var body: some View {
        VStack(spacing: 20) {
            
            Image("Accueil") // Remplacez "yourImageName" par le nom de votre image
                .resizable()
                .scaledToFit() // Ajuste l'image pour tenir dans son cadre en conservant ses proportions
                .frame(width: 180, height: 150) // Définissez la taille de l'image
            
            
            InfosView()
                .background(Color.blue)
                .shadow(radius: 5)
            
            Spacer()
            
            
            FestivalEnCoursView()
                .padding()
                .background(Color.white)
                .cornerRadius(15)
                .shadow(radius: 5)
            
            
            NewsView()
                .cornerRadius(15)
                .shadow(radius: 5)
            
            Spacer()
            
        }
    }
}

struct AccueilView_Previews: PreviewProvider {
    static var previews: some View {
        AccueilView()
    }
}
