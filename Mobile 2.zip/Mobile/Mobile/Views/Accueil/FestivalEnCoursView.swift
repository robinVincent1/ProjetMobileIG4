//
//  FestivalEnCoursView.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import SwiftUI

struct FestivalEnCoursView: View {
    @State private var festival: Festival?
    @State private var isLoading = false
    @State private var errorMessage = ""
    @State private var user: User?
    @State private var isInscrit: Bool = false

    
    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Chargement en cours...")
            } else if let festival = festival {
                VStack(alignment: .leading, spacing: 10) {
                    Text(festival.nom)
                        .font(.title2)
                        .foregroundColor(.blue)
                    Text(" \(festival.date)")
                        .font(.body)
                        .foregroundColor(.black)                }
                
                if isInscrit {
                    Text("Vous êtes inscrit à ce festival !")
                } else {
                    Button(action: {
                        inscription(idFestival: festival.idFestival)
                        isInscrit = true
                    }) {
                        Text("S'inscrire")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 150) // Largeur fixe
                            .background(Color.blue)
                            .cornerRadius(8)
                            .shadow(color: .gray, radius: 3, x: 0, y: 2)
                    }
                }
            } else { 
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .onAppear {
            // Appel de la fonction pour récupérer l'utilisateur depuis l'API
            getUserFromAPI { result in
                switch result {
                case .success(let user):
                    self.user = user
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
            
            // Appel de la fonction pour récupérer le festival depuis l'API
            getFestivalsFromAPI { result in
                switch result {
                case .success(let festival):
                    self.festival = festival
                    self.isLoading = false
                    
                    // Vérifier si l'utilisateur est inscrit après avoir récupéré le festival
                    if let festivalId = self.festival?.idFestival, let userIdString = self.user?.idFestival, let userId = Int(userIdString) {
                        self.isInscrit = festivalId == userId
                    }
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
            self.isLoading = true
        }
    }
}

struct FestivalEnCoursView_Previews: PreviewProvider {
    static var previews: some View {
        FestivalEnCoursView()
    }
}
