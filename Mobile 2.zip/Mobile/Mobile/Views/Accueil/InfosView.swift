//
//  InfosView.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import SwiftUI

struct InfosView: View {
    @State private var infos: [Infos] = []
    @State private var isLoading = false
    @State private var errorMessage = ""
    
    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Chargement en cours...")
            } else if !infos.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(infos, id: \.idInfos) { infoItem in
                            InfoCard(info: infoItem)
                        }
                    }
                    .padding()
                }
            } else {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .onAppear {
            // Appel de la fonction pour récupérer les informations depuis l'API
            getInfosFromAPI { result in
                switch result {
                case .success(let infosList):
                    self.infos = infosList
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
                self.isLoading = false
            }
            self.isLoading = true
        }
    }
}

struct InfoCard: View {
    let info: Infos
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(info.titre)
                .font(.title2)
                .foregroundColor(.white)
                .bold()
            Text(info.description)
                .foregroundColor(.white)
        }

        .frame(width: 200, height: 120)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(10)
    }
}

struct InfosView_Previews: PreviewProvider {
    static var previews: some View {
        InfosView()
    }
}


