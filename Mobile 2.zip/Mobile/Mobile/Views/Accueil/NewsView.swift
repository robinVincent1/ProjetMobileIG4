import SwiftUI

struct NewsView: View {
    @State private var news: [News] = []
    @State private var isLoading = false
    @State private var errorMessage = ""
    
    var body: some View {
        VStack {
            if isLoading {
                ProgressView("Chargement en cours...")
            } else if !news.isEmpty {
                ScrollView(.horizontal, showsIndicators: true) { // Utilisation de ScrollView pour permettre le défilement horizontal
                    HStack(spacing: 20) { // Utilisation de HStack pour placer les news horizontalement
                        ForEach(news, id: \.idNews) { newsItem in
                            VStack(alignment: .leading) {
                                Text(newsItem.titre)
                                    .font(.headline)
                                    .foregroundColor(.blue)
                                Text(newsItem.description)
                                    .font(.body)
                                    .foregroundColor(.black)
                            }
                            .padding()
                        }
                    }
                    .padding(.horizontal) // Espacement horizontal pour les news
                }
                .frame(height: 180) // Hauteur fixe pour la ScrollView
            } else {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .onAppear {
            // Appel de la fonction pour récupérer les nouvelles depuis l'API
            getNewsFromAPI { result in
                switch result {
                case .success(let newsList):
                    self.news = newsList
                    print(newsList)
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
                self.isLoading = false
            }
            self.isLoading = true
        }
    }
}

struct NewsView_Previews: PreviewProvider {
    static var previews: some View {
        NewsView()
    }
}
