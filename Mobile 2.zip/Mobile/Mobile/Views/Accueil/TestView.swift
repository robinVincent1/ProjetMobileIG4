//
//  TestView.swift
//  Mobile
//
//  Created by Robin Vincent on 16/03/2024.
//

import SwiftUI

struct TestView: View {
    var body: some View {
        PlanningPersoView()
    }
}

#Preview {
    TestView()
}
