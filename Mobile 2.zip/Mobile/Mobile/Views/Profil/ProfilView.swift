import SwiftUI

struct ProfileView: View {
    @State private var isEditing = false
    
    @State private var user: User? // Utilisez un Optional pour stocker l'utilisateur récupéré depuis l'API
    
    @State private var pseudo : String = ""
    @State private var postalAdress : String = ""
    @State private var telephone : String = ""
    @State private var association : String = ""
    @State private var email: String = ""
    
    @State private var showImagePicker = false
    @State private var selectedImage: UIImage?
    
    @State private var showSuccessAnimation : Bool = false // Nouvelle variable d'état pour contrôler l'animation
    
    var body: some View {
        VStack {
            // Avatar with the first letter of the first name
            if let user = user { // Affichez les détails de l'utilisateur s'il est disponible
                
                Spacer()
                AvatarView(user: user, anim: showSuccessAnimation)
                    .bold()
                
                Spacer()
                
                HStack {
                    VStack {
                        Text("\(user.firstName) \(user.lastName)")
                            .font(.title2)
                            .bold()
                        Text("Nom")
                            .italic()
                    }
                    VStack {
                        Text("\(user.nbEdition)")
                            .font(.title2)
                            .bold()
                        Text("Edition(s)")
                            .italic()
                    }
                    VStack {
                        Text("\(user.role)")
                            .font(.title2)
                            .bold()
                        Text("Role")
                            .italic()
                    }
                }
                
                
                // Champs éditables avec les informations de l'utilisateur
                HStack {
                    VStack {
                        Text("Pseudo")
                            .padding()
                        Text("E-mail")
                            
                        Text("Adresse")
                            .padding()
                        Text("Téléphone")
                            
                        Text("Association")
                            .padding()
                    }
                    VStack {
                        TextField(user.pseudo ?? "Pseudo", text: $pseudo)
                            .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                            .background(RoundedRectangle(cornerRadius: 8).stroke(.gray, lineWidth: 2))
                            .foregroundColor(.black)
                        TextField(user.email, text: $email)
                            .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                            .background(RoundedRectangle(cornerRadius: 8).stroke(.gray, lineWidth: 2))
                            .foregroundColor(.black)
                        TextField(user.postalAdress ?? "Adresse", text: $postalAdress)
                            .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                            .background(RoundedRectangle(cornerRadius: 8).stroke(.gray, lineWidth: 2))
                            .foregroundColor(.black)
                        TextField(user.telephone ?? "Téléphone", text: $telephone )
                            .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                            .background(RoundedRectangle(cornerRadius: 8).stroke(.gray, lineWidth: 2))
                            .foregroundColor(.black)
                        TextField(user.association ?? "Association", text: $association )
                            .padding(EdgeInsets(top: 8, leading: 16, bottom: 8, trailing: 16))
                            .background(RoundedRectangle(cornerRadius: 8).stroke(.gray, lineWidth: 2))
                            .foregroundColor(.black)
                    }
                }
                .padding()
             
 
                
                Button(action: {
                    // Appel de la fonction pour récupérer l'utilisateur depuis l'API
                    updateUserToAPI(email: email, telephone: telephone, association: association, pseudo: pseudo, adresse: postalAdress) { result in
                        switch result {
                        case .success(let updatedUser):
                            self.user = updatedUser // Affectez l'utilisateur récupéré à la propriété user
                            self.showSuccessAnimation = true // Déclencher l'animation de succès
                            // Réinitialiser l'état de l'animation après quelques secondes
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                self.showSuccessAnimation = false
                            }
                        case .failure(let error):
                            print("Erreur lors de la récupération de l'utilisateur modifié: \(error)")
                            // Traitez l'erreur ici
                        }
                    }
                }) {
                    Text("Envoyer")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.blue)
                        .cornerRadius(8)
                        .shadow(color: .gray, radius: 3, x: 0, y: 2)
                }

                Spacer()
                
            } else {
                // Placeholder pour afficher une indication de chargement ou un message d'erreur
                Text("Chargement en cours...")
            }
            
            Spacer()
        }
        .padding()
        .navigationBarTitle("Profil")
        .navigationBarItems(trailing: Button(action: {
            isEditing.toggle()
            if isEditing {
                
            }
        }) {
            Text(isEditing ? "Valider" : "Modifier")
        })
        .onAppear {
            // Appel de la fonction pour récupérer l'utilisateur depuis l'API
            getUserFromAPI { result in
                switch result {
                case .success(let user):
                    self.user = user // Affectez l'utilisateur récupéré à la propriété user
                    self.email = user.email
                    self.telephone = user.telephone ?? ""
                    self.association = user.association ?? ""
                    self.postalAdress = user.postalAdress ?? ""
                    self.pseudo = user.pseudo ?? ""
                case .failure(let error):
                    print("Erreur lors de la récupération de l'utilisateur : \(error)")
                    // Traitez l'erreur ici
                }
            }
        }
        .sheet(isPresented: $showImagePicker) {
            // Image picker
            
        }
    }
}


struct AvatarView: View {
    var user: User
    var anim : Bool
    
    var body: some View {
        ZStack {
            Circle()
                .fill(Color.blue)
                .frame(width: 100, height: 100)
            // Ajouter l'animation du cercle vert
            .overlay(
                Circle()
                    .stroke(Color.blue, lineWidth: 48)
                    .scaleEffect(anim ? 1 : 0) // Mettre à l'échelle le cercle selon l'état d'animation
                    .opacity(anim ? 0 : 1) // Rendre le cercle invisible au début
                    .animation(.easeInOut(duration: 0.5)) // Animation de transition
                    .onAppear {
                        // Réinitialiser l'état de l'animation lorsque la vue apparaît
                        
                    }
            )
            
            Text(user.firstName.prefix(1))
                .font(.title)
                .foregroundColor(.white)
        }
        .padding(.bottom, 20)
    }
}

struct EditableField: View {
    var title: String
    var placeholder: String
    @Binding var text: String
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.headline)
            TextField(placeholder, text: $text)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }
        .padding(.vertical, 5)
    }
}



struct ProfilView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
