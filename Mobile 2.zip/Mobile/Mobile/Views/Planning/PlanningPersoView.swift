//
//  PlanningPersoView.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import SwiftUI
import UIKit

struct PlanningPersoView: UIViewControllerRepresentable{
    func makeUIViewController(context: Context) -> PlanningPersoController{
        return PlanningPersoController()
    }
    
    func updateUIViewController(_ uiViewController: PlanningPersoController, context: Context) {
        //code
    }
    
    typealias UIViewControllerType = PlanningPersoController
}

