//
//  CreneauModel.swift
//  Mobile
//
//  Created by Robin Vincent on 16/03/2024.
//

import Foundation

import Foundation

struct Creneau : Codable {
    var idCreneau: Int
    var LigneId: Int
    var JourId: Int
    var HoraireId: Int
    var idPlanning: Int
    var date: String
    var ouvert: Bool
    var heure_debut: Int
    var heure_fin: Int
    var titre: String
    var nb_max: Int
    var nb_inscrit: Int
    var ReferentId: Int
}

func getCreneauxFromAPI(url : String) -> [Creneau]? {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    
    guard let idUser = idUser, let token = token else {
        // Gérer le cas où l'ID utilisateur ou le jeton n'est pas disponible
        return nil
    }
    
    let url = URL(string: url)!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    var creneaux: [Creneau] = []
    
    let semaphore = DispatchSemaphore(value: 0)
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        defer {
            semaphore.signal()
        }
        
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            return
        }
        
        do {
            creneaux = try JSONDecoder().decode([Creneau].self, from: data)
        } catch {
            // Gérer les erreurs de décodage JSON
        }
    }.resume()
    
    _ = semaphore.wait(timeout: .distantFuture)

    return creneaux
}


func getCreneauFromAPI(url : String) -> Creneau? {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    
    guard let idUser = idUser, let token = token else {
        // Gérer le cas où l'ID utilisateur ou le jeton n'est pas disponible
        return nil
    }
    
    let url = URL(string: url)!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    var creneau: Creneau? = nil
    
    let semaphore = DispatchSemaphore(value: 0)
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        defer {
            semaphore.signal()
        }
        
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            return
        }
        
        do {
            creneau = try JSONDecoder().decode(Creneau.self, from: data)
        } catch {
            // Gérer les erreurs de décodage JSON
        }
    }.resume()
    
    _ = semaphore.wait(timeout: .distantFuture)
    return creneau
}


func getIsInscrit(url: String, completion: @escaping (Bool) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    
    guard let idUser = idUser, let token = token else {
        // Gérer le cas où l'ID utilisateur ou le jeton n'est pas disponible
        completion(false)
        return
    }
    
    guard let url = URL(string: url) else {
        // Gérer le cas où l'URL est incorrecte
        completion(false)
        return
    }
    
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            completion(false)
            return
        }
        
        if let boolValue = try? JSONDecoder().decode(Bool.self, from: data) {
            // Si le décodage réussit, utilisez la valeur booléenne renvoyée par l'API
            completion(boolValue)
        } else {
            // Si le décodage échoue, renvoyez false
            completion(false)
        }
    }.resume()
}


