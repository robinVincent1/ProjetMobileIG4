//
//  InfoModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation

struct Infos: Codable {
    let idInfos: Int
    let titre: String
    let description: String
}

