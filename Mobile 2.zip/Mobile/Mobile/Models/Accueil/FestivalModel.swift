//
//  FestivalModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation

import Foundation

struct Festival: Codable {
    var idFestival: Int
    var nom: String
    var date: String
    var nbReferent: Int
    var nbRespoSoiree: Int
    var nbAccueilBenevole: Int
    var nbBenevole: Int
    var enCours: Bool
    var idPlanning: String
}
