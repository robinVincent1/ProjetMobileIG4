//
//  FestivalViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation

//fonction pour récupérer le festival en cours
func getFestivalsFromAPI(completion: @escaping (Result<Festival, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        completion(.failure(AuthenticationError.missingCredentials))
        return
    }
    
    // Déballage de l'optionnel
    let url = URL(string: "\(urlAPI)/festival/enCours")! // Endpoint pour récupérer les festivals
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.failure(AuthenticationError.apiError))
            }
            return
        }
        
        do {
            let festivalsList = try JSONDecoder().decode(Festival.self, from: data)
            completion(.success(festivalsList))
        } catch {
            completion(.failure(error))
        }
    }.resume()
}

func inscription(idFestival: Int) {
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    if let idUser = idUser {
        updateUserInAPI(userId: idUser, festivalId: idFestival, flexible: true) { result in
            switch result {
            case .success(let updatedUser):
                // Traiter l'utilisateur mis à jour
                print("Utilisateur mis à jour : \(updatedUser)")
            case .failure(let error):
                // Gérer l'erreur
                print("Erreur lors de la mise à jour de l'utilisateur : \(error)")
            }
        }
    }
}
