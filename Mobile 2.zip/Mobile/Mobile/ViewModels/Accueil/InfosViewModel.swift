//
//  InfosViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation

// Fonction pour récupérer les informations à partir de l'API
func getInfosFromAPI(completion: @escaping (Result<[Infos], Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        completion(.failure(AuthenticationError.missingCredentials))
        return
    }
    
    // Déballage de l'optionnel
    let url = URL(string: "\(urlAPI)/infos")! // Endpoint pour récupérer les informations
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.failure(AuthenticationError.apiError))
            }
            return
        }
        
        do {
            let infosList = try JSONDecoder().decode([Infos].self, from: data)
            completion(.success(infosList))
        } catch {
            completion(.failure(error))
        }
    }.resume()
}

