//
//  ForumViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 20/03/2024.
//

import Foundation

// ViewModel pour gérer les fonctionnalités du forum
class ForumViewModel: ObservableObject {
    @Published var questions: [Question] = [] // Liste des questions
    @Published var errorMessage = "" // Message d'erreur
    @Published var isLoading = true // Indicateur de chargement
    @Published var user: User? = nil // Utilisateur actuel
    @Published var presented: Bool = false // Indicateur de présentation
    
    // Fonction pour récupérer les questions depuis l'API
    func fetchQuestion() {
        let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain() // Récupérer l'ID de l'utilisateur depuis le trousseau d'accès sécurisé
        if let _ = idUser {
            // Appel de la fonction pour récupérer l'utilisateur depuis l'API
            getUserFromAPI { result in
                switch result {
                case .success(let user):
                    self.isLoading = false
                    DispatchQueue.main.async {
                        self.user = user
                    }
                case .failure(let error):
                    print("Erreur lors de la récupération de l'utilisateur : \(error)")
                    // Traitez l'erreur ici
                }
            }
        }
        
        // Appel de la fonction pour récupérer les questions depuis l'API
        getQuestionsFromAPI { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let questionList):
                    self.questions = questionList
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    // Fonction pour envoyer une réponse à une question
    func sendReponse(createur: String, responseText: String, questionId: Int) {
        postResponseToAPI(createur: createur, responseText: responseText, questionId: questionId) { result in
            DispatchQueue.main.async {
                switch result {
                case .success():
                    self.fetchQuestion() // Actualiser la liste des questions après l'envoi de la réponse
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    // Fonction pour envoyer une nouvelle question
    func sendQuestion(createur: String, question: String, objet: String) {
        postQuestionToAPI(createur: createur, question: question, objet: objet) { result in
            DispatchQueue.main.async {
                switch result {
                case .success():
                    self.fetchQuestion() // Actualiser la liste des questions après l'envoi de la question
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    // Fonction pour supprimer une réponse
    func deleteReponse(reponseId: Int) {
        deleteReponseToAPI(reponseId: reponseId) { result in
            DispatchQueue.main.async {
                switch result {
                case .success():
                    self.fetchQuestion() // Actualiser la liste des questions après la suppression de la réponse
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    // Fonction pour supprimer une question
    func deleteQuestion(questionId: Int) {
        deleteQuestionToAPI(questionId: questionId) { result in
            DispatchQueue.main.async {
                switch result {
                case .success():
                    self.fetchQuestion() // Actualiser la liste des questions après la suppression de la question
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
}
