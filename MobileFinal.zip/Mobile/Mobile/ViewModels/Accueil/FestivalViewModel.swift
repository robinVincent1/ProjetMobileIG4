//
//  FestivalViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation

// ViewModel pour gérer les données du festival en cours
class FestivalEnCoursViewModel: ObservableObject {
    @Published var festival: Festival? // Données du festival en cours
    @Published var isLoading = false // Indicateur de chargement
    @Published var errorMessage = "" // Message d'erreur en cas d'échec de récupération des données
    @Published var user: User? // Utilisateur actuel
    @Published var isInscrit = false // Booléen pour indiquer si l'utilisateur est inscrit au festival

    // Fonction pour récupérer les données du festival en cours
    func fetchFestivalData() {
        isLoading = true // Activation de l'indicateur de chargement
        // Appel de la fonction pour récupérer les données de l'utilisateur depuis l'API
        getUserFromAPI { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    self.user = user // Attribution des données de l'utilisateur
                    self.getFestival() // Appel de la fonction pour récupérer les données du festival
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)" // Attribution du message d'erreur en cas d'échec
                    self.isLoading = false // Désactivation de l'indicateur de chargement
                }
            }
        }
    }

    // Fonction privée pour récupérer les données du festival en cours depuis l'API
    private func getFestival() {
        // Appel de la fonction pour récupérer les données des festivals depuis l'API
        getFestivalsFromAPI { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let festival):
                    self.festival = festival // Attribution des données du festival
                    self.isLoading = false // Désactivation de l'indicateur de chargement
                    // Vérification de l'inscription de l'utilisateur au festival
                    if let userId = self.user?.idFestival {
                        self.isInscrit = String(festival.idFestival) == userId
                    }
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)" // Attribution du message d'erreur en cas d'échec
                    self.isLoading = false // Désactivation de l'indicateur de chargement
                }
            }
        }
    }

    // Fonction pour s'inscrire au festival
    func inscrireAuFestival() {
        guard let festivalId = festival?.idFestival else { return }
        inscription(idFestival: festivalId) // Appel de la fonction pour s'inscrire au festival via l'API
        self.isInscrit = true // Mise à jour de l'indicateur d'inscription
    }
}
