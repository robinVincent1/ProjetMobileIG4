//
//  InfosViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation

// ViewModel pour gérer les informations
class InfosViewModel: ObservableObject {
    @Published var infos: [Infos] = [] // Liste des informations
    @Published var errorMessage = "" // Message d'erreur en cas d'échec de récupération des données
    @Published var isLoading = false // Indicateur de chargement

    // Fonction pour récupérer les informations depuis l'API
    func fetchInfos() {
        isLoading = true // Activation de l'indicateur de chargement
        // Appel de la fonction pour récupérer les informations depuis l'API
        getInfosFromAPI { result in
            DispatchQueue.main.async {
                self.isLoading = false // Désactivation de l'indicateur de chargement après la récupération des données
                switch result {
                case .success(let infosList):
                    self.infos = infosList // Attribution des informations récupérées
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)" // Attribution du message d'erreur en cas d'échec
                }
            }
        }
    }
}
