//
//  NewsViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation

// ViewModel pour gérer les actualités
class NewsViewModel: ObservableObject {
    @Published var news: [News] = [] // Liste des actualités
    @Published var errorMessage = "" // Message d'erreur en cas d'échec de récupération des données
    @Published var isLoading = false // Indicateur de chargement

    // Fonction pour récupérer les actualités depuis l'API
    func fetchNews() {
        isLoading = true // Activation de l'indicateur de chargement
        // Appel de la fonction pour récupérer les actualités depuis l'API
        getNewsFromAPI { result in
            DispatchQueue.main.async {
                self.isLoading = false // Désactivation de l'indicateur de chargement après la récupération des données
                switch result {
                case .success(let newsList):
                    self.news = newsList // Attribution des actualités récupérées
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)" // Attribution du message d'erreur en cas d'échec
                }
            }
        }
    }
}
