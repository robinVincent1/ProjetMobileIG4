//
//  JeuViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 18/03/2024.
//

import Foundation

// ViewModel pour gérer les données liées aux jeux et à l'espace
class ListeJeuViewModel: ObservableObject {
    @Published var csv: [Csv] = [] // Liste des jeux (CSV)
    @Published var errorMessage = "" // Message d'erreur en cas d'échec de récupération des données
    @Published var isLoading = false // Booléen pour indiquer si les données sont en cours de chargement
    @Published var listeEspace: [Espace] = [] // Liste des espaces de jeu

    // Fonction pour récupérer les données CSV des jeux à partir de l'API
    func fetchCsv(zone: String) {
        isLoading = true // Activation de l'indicateur de chargement
        // Appel de la fonction pour récupérer les données
        getCsvFromAPI(zone: zone) { result in
            DispatchQueue.main.async {
                self.isLoading = false // Désactivation de l'indicateur de chargement après récupération des données
                switch result {
                case .success(let fetchedCsv):
                    self.csv = fetchedCsv // Attribution des données récupérées à la variable 'csv'
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)" // Attribution du message d'erreur en cas d'échec
                }
            }
        }
    }
    
    // Fonction pour récupérer les données des espaces de jeu à partir de l'API
    func fetchEspace() {
        isLoading = true // Activation de l'indicateur de chargement
        // Appel de la fonction pour récupérer les données
        getEspaceFromAPI { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let fetchedEspace):
                    self.listeEspace = fetchedEspace // Attribution des données récupérées à la variable 'listeEspace'
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)" // Attribution du message d'erreur en cas d'échec
                }
            }
        }
    }
}
