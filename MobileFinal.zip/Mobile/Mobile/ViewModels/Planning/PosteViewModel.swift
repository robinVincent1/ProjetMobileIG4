//
//  PosteViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 17/03/2024.
//

import Foundation

// ViewModel pour gérer les postes
class PosteViewModel: ObservableObject {
    @Published var creneaux: [Creneau] = [] // Liste des créneaux pour le poste
    @Published var date :  String = "" // Date du poste
    @Published var annee : String = "" // Année du poste
    @Published var mois : String = "" // Mois du poste
    @Published var jour: String = "" // Jour du poste
    @Published var heuredebut : Int = 0 // Heure de début du poste
    @Published var heurefin: Int = 0 // Heure de fin du poste
    @Published var dejaInscrit = false // Statut d'inscription de l'utilisateur au poste
    
    // Fonction pour récupérer les créneaux associés au poste depuis l'API
    func fetchCreneaux(id: Int) {
        // Récupération du créneau principal associé au poste
        guard let creneau = getCreneauFromAPI(url: "\(urlAPI)/creneau/getbyid/\(id)") else {
            return
        }
        
        // Convertir les valeurs d'heure_debut et heure_fin en chaînes de caractères
        let heureDebutString = String(creneau.heure_debut)
        let heureFinString = String(creneau.heure_fin)
        
        // Utiliser les chaînes de caractères converties dans l'URL pour récupérer les créneaux associés
        getCreneauxByHoraire(url: "\(urlAPI)/creneau/getbydateandhoraire/\(creneau.date)/\(heureDebutString)/\(heureFinString)/\(creneau.isAnimation)") { fetchedCreneaux in
            if let fetchedCreneaux = fetchedCreneaux {
                DispatchQueue.main.async {
                    self.creneaux = fetchedCreneaux
                    if !self.creneaux.isEmpty {
                        // Récupérer la date et les détails de l'horaire du premier créneau
                        self.date = self.creneaux[0].date
                        let dateAr = self.date.components(separatedBy: "-")
                        self.annee = dateAr[0]
                        self.mois = dateAr[1]
                        self.jour = dateAr[2]
                        self.heuredebut = self.creneaux[0].heure_debut
                        self.heurefin = self.creneaux[0].heure_fin
                    }
                }
            } else {
                self.creneaux = [] // Ou toute autre logique de gestion d'erreur
            }
            
            // Vérification de l'inscription de l'utilisateur à chaque créneau récupéré
            let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
            for c in self.creneaux {
                if let idUser = idUser {
                    // Appel de la fonction getIsInscrit pour vérifier si l'utilisateur est inscrit à ce créneau
                    getIsInscrit(url: "\(urlAPI)/creneau_benevole/isInscrit/\(String(describing: idUser))/\(c.idCreneau)") { stringValue in
                        // Gérer la réponse reçue dans la complétion
                        // Vous pouvez faire d'autres traitements en fonction de la valeur reçue
                        print(stringValue)
                        if stringValue == "oui" || stringValue == "flexible" {
                            self.dejaInscrit = true
                        }
                    }
                }
            }
        }
    }
}
