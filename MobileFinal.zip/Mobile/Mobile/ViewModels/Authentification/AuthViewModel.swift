//
//  AuthViewModel.swift
//  ProjetMobileIG4
//
//  Created by Robin Vincent on 12/03/2024.
//

import Foundation

// ViewModel pour gérer l'authentification de l'utilisateur
class AuthManager: ObservableObject {
    @Published var isAuthenticated = false // Statut d'authentification de l'utilisateur
    private let tokenKey = "AuthToken" // Clé pour stocker le jeton d'authentification dans UserDefaults
    
    // Propriété calculée pour récupérer le jeton d'authentification depuis UserDefaults
    var authToken: String? {
        UserDefaults.standard.string(forKey: tokenKey)
    }
    
    // Fonction pour connecter l'utilisateur en stockant le jeton d'authentification dans UserDefaults
    func login(token: String) {
        UserDefaults.standard.set(token, forKey: tokenKey)
        isAuthenticated = true // Mettre à jour le statut d'authentification
    }
    
    // Fonction pour déconnecter l'utilisateur en supprimant le jeton d'authentification de UserDefaults
    func logout() {
        UserDefaults.standard.removeObject(forKey: tokenKey)
        isAuthenticated = false // Mettre à jour le statut d'authentification
        AuthenticationManager.shared.deleteTokenFromKeychain() // Supprimer également le jeton d'authentification du trousseau d'accès sécurisé
    }
}
