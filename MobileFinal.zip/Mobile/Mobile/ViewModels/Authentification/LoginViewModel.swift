//
//  LoginViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 21/03/2024.
//

import Foundation

import SwiftUI

class LoginViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    @Published var user: UserConnected? = nil
    @Published var wrongUsername: CGFloat = 0
    @Published var wrongPassword: CGFloat = 0
    
    func authenticateUser() {
        // Votre logique d'authentification ici
    }
    
    // Fonction pour authentifier l'utilisateur en utilisant les informations fournies
    func authenticateUser(authManager: AuthManager) {
            guard let url = URL(string: "http://localhost:8080/user/login") else {
                return
            }
            // Création des données JSON à envoyer
            let userData = [
                "email": email,
                "password": password
            ]
            
            do {
                // Encodage des données JSON
                let jsonData = try JSONSerialization.data(withJSONObject: userData, options: [])
                
                // Création de la requête URLRequest avec la méthode POST
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.httpBody = jsonData
                
                // Création de la session URLSession et envoi de la requête
                URLSession.shared.dataTask(with: request) { data, response, error in
                    guard let data = data, error == nil else {
                        print("Erreur lors de la récupération des données : \(error?.localizedDescription ?? "Erreur inconnue")")
                        return
                    }
                    
                    do {
                        // Désérialisation des données JSON en un objet UserConnected
                        let decodedData = try JSONDecoder().decode(UserConnected.self, from: data)
                        DispatchQueue.main.async {
                            self.user = decodedData
                            // Vérification des informations de connexion ici
                            if self.user != nil {
                                self.wrongUsername = 0
                                self.wrongPassword = 0
                                
                                //sauvegarder le token
                                let token = decodedData.accessToken
                                let idUser = decodedData.idUser

                                AuthenticationManager.shared.saveIdUserToKeychain(idUser: idUser)
                                AuthenticationManager.shared.saveTokenToKeychain(token: token)
                                
                                //se loger avec le token
                                authManager.login(token: decodedData.accessToken)
                            } else {
                                self.wrongUsername = 2
                            }
                        }
                    } catch {
                        print("Erreur lors de la désérialisation de la réponse JSON : \(error.localizedDescription)")
                    }
                }.resume()
            } catch {
                print("Erreur lors de la création des données JSON : \(error.localizedDescription)")
            }
        }
}
