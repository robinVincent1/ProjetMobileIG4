//
//  RegisterViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 21/03/2024.
//

import Foundation

import SwiftUI

class RegisterViewModel: ObservableObject {
    @Published var pseudo = ""
    @Published var password = ""
    @Published var confirmPassword = ""
    @Published var email = ""
    @Published var firstName = ""
    @Published var lastName = ""
    @Published var telephone = ""
    @Published var user : UserConnected? = nil
    
    // Fonction pour envoyer les données d'inscription à l'API
    func registerUser(authManager: AuthManager) {
        // Vérification des champs obligatoires
        guard !pseudo.isEmpty, !password.isEmpty, !confirmPassword.isEmpty, !email.isEmpty else {
            // Gérer l'erreur
            return
        }
        
        // Vérification de la correspondance des mots de passe
        guard password == confirmPassword else {
            // Gérer l'erreur
            return
        }
        
        // Création de l'objet utilisateur
        let newUser = User(
            email: email,
            password: password,
            active: true,
            role: "Bénévole",
            firstName: firstName,
            lastName: lastName,
            nbEdition: 0,
            pseudo: pseudo,
            postalAdress: nil,
            propo: nil,
            association: nil,
            telephone: telephone,
            photoProfil: nil,
            idFestival: nil,
            flexible: nil
        )
        
        // Encodage de l'utilisateur en JSON
        guard let encodedUser = try? JSONEncoder().encode(newUser) else {
            // Gérer l'erreur
            return
        }
        
        // Envoi des données à l'API
        guard let url = URL(string: "\(urlAPI)/user") else {
            // Gérer l'erreur
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = encodedUser
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print(error)
                return
            }
            
            // Vérifier la réponse de l'API et effectuer les actions nécessaires
            if let data = data {
                do {
                    let decodedResponse = try JSONDecoder().decode(UserConnected.self, from: data)
                    DispatchQueue.main.async {
                        self.user = decodedResponse
                        let token = decodedResponse.accessToken
                        let idUser = decodedResponse.idUser
                        
                        //sauvergarder le token
                        AuthenticationManager.shared.saveTokenToKeychain(token: token)
                        AuthenticationManager.shared.saveIdUserToKeychain(idUser: idUser)
                        
                        //se loger avec le token
                        authManager.login(token: decodedResponse.accessToken)
                        
                    }
                } catch {
                    // Gérer l'erreur de désérialisation
                    print("Erreur lors de la désérialisation de la réponse JSON : \(error.localizedDescription)")
                }
            }
        }.resume()
    }
}
