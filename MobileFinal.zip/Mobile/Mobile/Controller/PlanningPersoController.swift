import UIKit
import CalendarKit

final class PlanningPersoController: DayViewController {
    
    var creneau : [Creneau] = []
    
    func fetchCreneauxAndUpdateList(date: Date) -> [EventDescriptor]? {
        _ = "" // Réinitialiser le message d'erreur
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" // Le format que vous souhaitez pour la date
        let dateString = dateFormatter.string(from: date)

        // Appeler la fonction pour récupérer les créneaux depuis l'API
        if let creneaux = getCreneauxFromAPI(isAnimation: 2, url: "\(urlAPI)/creneau/getbydateandiduser/\(dateString)/2") {
            var eventDescriptors: [EventDescriptor] = []
            // Parcourir la liste de créneaux et créer un EventDescriptor pour chaque créneau
            for creneau in creneaux {
                let eventDescriptor = generateEventFromCreneau(creneau)
                eventDescriptors.append(eventDescriptor)
            }
            return eventDescriptors
        } else {
            // Gérer l'erreur si la récupération des créneaux échoue
            print("Failed to fetch creneaux")
            return nil
        }
    }


    override func dayView(dayView: DayView, didLongPressTimelineAt date: Date) {
        print("Did long press timeline at date \(date)")
        // Cancel editing current event and start creating a new one
        endEventEditing()
        
        // Call fetchCreneauxAndUpdateList asynchronously
        if let eventDescriptors = fetchCreneauxAndUpdateList(date: date) {
            // Once fetchCreneauxAndUpdateList completes and returns the event descriptors, create the events
            for eventDescriptor in eventDescriptors {
                print("Creating a new event")
                self.create(event: eventDescriptor, animated: true)
            }
        } else {
            // Handle the case where fetching creneaux fails
            print("Failed to fetch creneaux")
        }
    }

    var generatedEvents = [EventDescriptor]()
    var alreadyGeneratedSet = Set<Date>()

    var colors = [UIColor.blue,
                  UIColor.yellow,
                  UIColor.green,
                  UIColor.red]

    private lazy var dateIntervalFormatter: DateIntervalFormatter = {
        let dateIntervalFormatter = DateIntervalFormatter()
        dateIntervalFormatter.dateStyle = .none
        dateIntervalFormatter.timeStyle = .short

        return dateIntervalFormatter
    }()

    override func loadView() {
        calendar.timeZone = TimeZone(identifier: "Europe/Paris")!

        dayView = DayView(calendar: calendar)
        view = dayView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "CalendarKit Demo"
        navigationController?.navigationBar.isTranslucent = false
        dayView.autoScrollToFirstEvent = true
        reloadData()
    }

    // MARK: EventDataSource

    override func eventsForDate(_ date: Date) -> [EventDescriptor] {
        if let eventDescriptors = fetchCreneauxAndUpdateList(date: date) {
            // Once fetchCreneauxAndUpdateList completes and returns the event descriptors, return the events
            return eventDescriptors
        } else {
            // Handle the case where fetching creneaux fails
            print("Failed to fetch creneaux")
            return []
        }
    }


    // MARK: DayViewDelegate

    private var createdEvent: EventDescriptor?

    override func dayViewDidSelectEventView(_ eventView: EventView) {
        guard let descriptor = eventView.descriptor as? Event else {
            return
        }
        print("Event has been selected: \(descriptor) \(String(describing: descriptor.userInfo))")
    }

    override func dayViewDidLongPressEventView(_ eventView: EventView) {
        guard let descriptor = eventView.descriptor as? Event else {
            return
        }
        endEventEditing()
        print("Event has been longPressed: \(descriptor) \(String(describing: descriptor.userInfo))")
        beginEditing(event: descriptor, animated: true)
        print(Date())
    }

    override func dayView(dayView: DayView, didTapTimelineAt date: Date) {
        endEventEditing()
        print("Did Tap at date: \(date)")
    }

    override func dayViewDidBeginDragging(dayView: DayView) {
        endEventEditing()
        print("DayView did begin dragging")
    }

    override func dayView(dayView: DayView, willMoveTo date: Date) {
        print("DayView = \(dayView) will move to: \(date)")
    }

    override func dayView(dayView: DayView, didMoveTo date: Date) {
        print("DayView = \(dayView) did move to: \(date)")
    }

    private func generateEventFromCreneau(_ creneau: Creneau) -> EventDescriptor {
        var referent: User?
        let group = DispatchGroup()
        
        // Ajouter la tâche à la synchronisation
        group.enter()
        getReferent(id: creneau.ReferentId) { result in
            switch result {
            case .success(let user):
                referent = user
            case .failure(let error):
                print("Erreur lors de la récupération de l'utilisateur:", error)
            }
            // Indiquer que la tâche est terminée
            group.leave()
        }
        
        // Attendre que toutes les tâches ajoutées à la synchronisation soient terminées
        group.wait()
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd HH:mm"
        
        let dateString = "\(creneau.date.prefix(4))/\(creneau.date.prefix(7).suffix(2))/\(creneau.date.suffix(2)) \(creneau.heure_debut):00"
        let startDate = formatter.date(from: dateString)!
        
        // Convertir les heures de début et de fin en minutes
        let heureDebutMinutes = creneau.heure_debut * 60
        let heureFinMinutes = creneau.heure_fin * 60
        
        // Calculer la durée de l'événement en minutes
        let duration = heureFinMinutes - heureDebutMinutes
        
        // Calculer la date de fin en ajoutant la durée à la date de début
        let endDate = Calendar.current.date(byAdding: .minute, value: duration, to: startDate)!
        
        let event = Event()
        event.dateInterval = DateInterval(start: startDate, end: endDate)
        event.text = creneau.titre
        if creneau.isAnimation == 0 {
            event.color = .blue
        }
        else{
            event.color = .red
        }
     
        
        var eventInfo = ""
        eventInfo += "                      Titre : \(creneau.titre)\n"
        if let referent = referent {
            eventInfo += "Referent: \n      Nom : \(referent.firstName) \(referent.lastName)\n"
            if let tel = referent.telephone {
                eventInfo += "      Telephone : \(tel)\n"
            }
            eventInfo += "      E-mail : \(referent.email)"
        }
        event.text = eventInfo
        
        return event
    }
    
override func dayView(dayView: DayView, didUpdate event: EventDescriptor) {
        print("did finish editing \(event)")
        print("new startDate: \(event.dateInterval.start) new endDate: \(event.dateInterval.end)")

        if let _ = event.editedEvent {
            event.commitEditing()
        }

        if let createdEvent = createdEvent {
            createdEvent.editedEvent = nil
            generatedEvents.append(createdEvent)
            self.createdEvent = nil
            endEventEditing()
        }

        reloadData()
    }
}

