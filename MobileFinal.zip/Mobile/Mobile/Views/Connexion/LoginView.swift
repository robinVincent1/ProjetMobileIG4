import SwiftUI

// Login est une vue permettant à l'utilisateur de se connecter.
struct Login: View {
    // ViewModel pour la logique de la vue de connexion.
    @StateObject var viewModel = LoginViewModel()
    
    // AuthManager pour gérer l'authentification de l'utilisateur.
    @ObservedObject var authManager: AuthManager
    
    // Variable d'état pour gérer la navigation vers l'écran d'inscription.
    @State private var navigateToRegister = false
    
    var body: some View {
        NavigationView {
            ZStack {
                // Arrière-plan de la vue de connexion.
                Color.blue
                    .ignoresSafeArea()
                
                // Forme de cercle pour la décoration.
                Circle()
                    .scale(1.7)
                    .foregroundColor(.white.opacity(0.15))
                Circle()
                    .scale(1.35)
                    .foregroundColor(.white)
                
                VStack {
                    // Contenu de la vue de connexion.
                    VStack {
                        // Image de logo et titre de connexion.
                        Image("Open")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 100, height: 100)
                        Text("Connexion")
                            .font(.largeTitle)
                            .bold()
                            .padding()
                            .foregroundColor(Color("DarkBlue"))
                    }
                    
                    // Champ de saisie pour l'identifiant.
                    TextField("Identifiant", text: $viewModel.email)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        .border(Color.red, width: viewModel.wrongUsername)
                    
                    // Champ de saisie sécurisé pour le mot de passe.
                    SecureField("Mot de passe", text: $viewModel.password)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                        .border(Color.red, width: viewModel.wrongPassword)
                    
                    // Bouton de connexion.
                    Button("Connexion") {
                        viewModel.authenticateUser(authManager: authManager)
                    }
                    .foregroundColor(.white)
                    .frame(width: 300, height: 50)
                    .background(Color.blue)
                    .cornerRadius(10)
                    
                    // Bouton pour aller vers l'écran d'inscription.
                    Button("Pas encore inscrit ?") {
                        navigateToRegister = true
                    }
                    .background(
                        // NavigationLink pour naviguer vers l'écran d'inscription.
                        NavigationLink("", destination: Register(authManager: authManager), isActive: $navigateToRegister)
                    )
                    .foregroundColor(.blue)
                    .padding()
                }
            }
        }
    }
}
