import SwiftUI

// Register est une vue permettant à l'utilisateur de s'inscrire.
struct Register: View {
    
    // AuthManager pour gérer l'authentification de l'utilisateur.
    @ObservedObject var authManager: AuthManager
    
    // ViewModel pour la logique de la vue d'inscription.
    @StateObject var viewModel = RegisterViewModel()
    
    // Variables d'état pour gérer l'affichage d'une alerte et la navigation vers l'écran de connexion.
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var navigateToLogin = false
    
    var body: some View {
        NavigationView {
            ZStack {
                // Arrière-plan de la vue d'inscription.
                Color.blue
                    .ignoresSafeArea()
                Circle()
                    .scale(1.7)
                    .foregroundColor(.white.opacity(0.15))
                Circle()
                    .scale(1.35)
                    .foregroundColor(.white)
                
                VStack {
                    // Titre de la vue d'inscription.
                    Text("Inscription")
                        .font(.largeTitle)
                        .bold()
                    
                    // Champ de saisie pour le prénom et le nom de famille sur la même ligne.
                    HStack {
                        TextField("Prénom", text: $viewModel.firstName)
                            .padding()
                            .frame(width: 150, height: 50)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(10)
                        
                        TextField("Nom de famille", text: $viewModel.lastName)
                            .padding()
                            .frame(width: 150, height: 50)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(10)
                    }
                    
                    // Champ de saisie pour l'identifiant et le téléphone sur la même ligne.
                    HStack {
                        TextField("Pseudo", text: $viewModel.pseudo)
                            .padding()
                            .frame(width: 150, height: 50)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(10)
                        
                        TextField("Téléphone", text: $viewModel.telephone)
                            .padding()
                            .frame(width: 150, height: 50)
                            .background(Color.black.opacity(0.05))
                            .cornerRadius(10)
                    }
                    
                    // Champ de saisie pour l'email.
                    TextField("Email", text: $viewModel.email)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    
                    // Champ de saisie sécurisé pour le mot de passe.
                    SecureField("Mot de passe", text: $viewModel.password)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    
                    // Champ de saisie sécurisé pour la confirmation du mot de passe.
                    SecureField("Confirmer le mot de passe", text: $viewModel.confirmPassword)
                        .padding()
                        .frame(width: 300, height: 50)
                        .background(Color.black.opacity(0.05))
                        .cornerRadius(10)
                    
                    // Bouton d'inscription.
                    Button("S'inscrire") {
                        viewModel.registerUser(authManager: authManager)
                    }
                    .foregroundColor(.white)
                    .frame(width: 300, height: 50)
                    .background(Color.blue)
                    .cornerRadius(10)
                    
                    // Bouton pour aller vers l'écran de connexion.
                    Button("Déjà inscrit ?") {
                        navigateToLogin = true
                    }
                    .background(
                        // NavigationLink pour naviguer vers l'écran de connexion.
                        NavigationLink("", destination: Login(authManager: authManager), isActive: $navigateToLogin)
                    )
                    .foregroundColor(.blue)
                    .padding(.top, 10)
                }
            }
        }
    }
}
