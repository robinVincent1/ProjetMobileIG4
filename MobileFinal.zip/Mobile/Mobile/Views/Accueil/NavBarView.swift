
// NavBarView est une vue qui affiche une barre de navigation en bas de l'écran avec des icônes pour naviguer entre différentes vues.

import SwiftUI

// NavBarView affiche une barre de navigation avec des icônes pour naviguer entre différentes vues.
struct NavBarView: View {
    // Tableau des noms d'icônes.
    var images : [String] = ["house","calendar", "questionmark.bubble", "person"]
    // État pour suivre l'icône sélectionnée.
    @State var selected = "house"
    // Espace de noms pour les animations.
    @Namespace private var namespace
    
    var body: some View {
        ZStack{
            // Affiche la vue correspondant à l'icône sélectionnée.
            if selected == "calendar"{
                PlanningView()
            }
            if selected == "house"{
                AccueilView()
            }
            if selected == "questionmark.bubble"{
                ForumView()
            }
            if selected == "person"{
                ProfileView()
            }
            // Affiche la barre de navigation en bas de l'écran.
            navBar
        }.edgesIgnoringSafeArea(.bottom)
    }
}

// Extension pour définir la barre de navigation.
extension NavBarView{
    private var navBar: some View {
        VStack{
            Spacer()
            // Affiche les icônes dans la barre de navigation.
            HStack(){
                HStack{
                    ForEach(images, id: \.self) { iconName in
                        // Si l'icône est sélectionnée, applique un effet d'échelle et une animation.
                        if selected == iconName {
                            ZStack{
                                Wave()
                                    .fill(.background)
                                    .frame(width: 80, height: 20)
                                    .scaleEffect(2)
                                    .offset(y:-10)
                                    .matchedGeometryEffect(id: "let1", in: namespace)
                                Image(systemName: selected)
                                    .font(.title3.bold())
                                    .foregroundColor(Color("BleuClair"))
                                    .padding(.horizontal,40)
                                    .offset(y:-30)
                                    .matchedGeometryEffect(id: "let2", in: namespace)
                                    .shadow(color: .black.opacity(0.5), radius: 10, x: 0, y: 0)
                            }
                        } else {
                            // Affiche l'icône non sélectionnée.
                            Image(systemName: iconName)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 20, height: 20)
                                .foregroundColor(.white)
                                .padding(20)
                                .onTapGesture {
                                    // Change l'icône sélectionnée avec animation.
                                    withAnimation {
                                        self.selected = iconName
                                    }
                                }
                        }
                    }
                }
                .padding(.bottom,30)
                .frame(maxWidth: .infinity)
                .background(
                    Color("BleuClair")
                )
            }
        }
    }
}


struct ContentView_: PreviewProvider {
    static var previews: some View {
        NavBarView()
            .preferredColorScheme(.light)
        
    } 
}  
  
struct Wave: Shape {
    func path(in rect: CGRect) -> Path {
        Path{path in
            path.move(to: .zero)
            path.addQuadCurve(to: CGPoint(x: rect.width * 0.4, y: rect.height * 0.7),
                              control: CGPoint(x: rect.width * 0.2, y: rect.minY))
            path.addQuadCurve(to: CGPoint(x: rect.width * 0.6, y: rect.height * 0.7),
                              control: CGPoint(x: rect.midX, y: rect.maxY))
            path.addQuadCurve(to: CGPoint(x: rect.maxX, y: rect.minY),
                              control: CGPoint(x: rect.width * 0.8, y: rect.minY))
            path.move(to: CGPoint(x: rect.minX, y: rect.minY))
            
            
        }
        
    } 
}
 
