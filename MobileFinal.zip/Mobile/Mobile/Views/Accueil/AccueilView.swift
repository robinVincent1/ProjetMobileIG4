import SwiftUI

// La vue AccueilView représente la page d'accueil de l'application.
struct AccueilView: View {
    var body: some View {
        // Utilisation de NavigationView pour la navigation entre les vues
        NavigationView {
            // ScrollView pour permettre le défilement vertical du contenu
            ScrollView {
                VStack {
                    // Utilisation de Spacer pour ajouter de l'espace entre les éléments
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    
                    // Affichage du logo de l'application
                    HStack {
                        Text("                    ")
                    }
                    .background(
                        Image("Accueil") // Affichage du logo de l'accueil
                            .resizable()
                            .scaledToFit()
                            .frame(width: 280, height: 280) // Taille ajustée du logo
                    )
                    
                    // Affichage des informations
                    InfosView()
                    
                    // Affichage des festivals en cours
                    FestivalEnCoursView()
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(radius: 5)
                    
                    Spacer()
                    Spacer()
                }
                .navigationBarTitle("") // Suppression du titre de la navigation bar
                .navigationBarHidden(true) // Masquage de la navigation bar
            }
        }
    }
}

// Aperçu de la vue AccueilView
struct AccueilView_Previews: PreviewProvider {
    static var previews: some View {
        AccueilView()
    }
}
