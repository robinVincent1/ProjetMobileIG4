import SwiftUI

// ProfileView affiche le profil de l'utilisateur avec la possibilité de le modifier.
struct ProfileView: View {
    @StateObject var viewModel = ProfileViewModel()

    var body: some View {
        NavigationView {
            VStack {
                // Affiche le contenu du profil de l'utilisateur ou une vue de chargement.
                if let user = viewModel.user {
                    ProfileContentView(user: user, isEditing: viewModel.isEditing, viewModel: viewModel)
                } else {
                    SkeletonCellView()
                }
            }
            .padding()
            // Ajoute un bouton de modification ou de validation selon le mode d'édition.
            .navigationBarItems(trailing: Button(action: {
                viewModel.isEditing.toggle()
                if !viewModel.isEditing {
                    viewModel.updateUser(email: viewModel.email, telephone: viewModel.telephone, association: viewModel.association, pseudo: viewModel.pseudo, postalAdress: viewModel.postalAdress)
                }
            }) {
                Text(viewModel.isEditing ? "Valider" : "Modifier")
            })
            // Charge les données du profil de l'utilisateur lors de l'apparition de la vue.
            .onAppear {
                viewModel.getUser()
            }
        }
    }
}

// ProfileContentView affiche les détails du profil de l'utilisateur.
struct ProfileContentView: View {
    var user: User
    var isEditing: Bool
    @ObservedObject var viewModel: ProfileViewModel

    var body: some View {
        VStack {
            // Titre du profil.
            Text("Profil")
                .font(.title)
                .bold()
                .foregroundColor(Color("DarkBlue"))
            // Affiche l'avatar de l'utilisateur.
            AvatarView(user: user)
            Spacer()
            
            // Affiche les détails du profil de l'utilisateur.
            HStack {
                Spacer()
                VStack {
                    Text("\(user.firstName) \(user.lastName)")
                        .font(.title3)
                        .bold()
                        .foregroundColor(Color.white)
                    Text("Nom")
                        .italic()
                        .foregroundColor(Color.white)
                }
                VStack {
                    Text("\(user.nbEdition)")
                        .font(.title3)
                        .bold()
                        .foregroundColor(Color.white)
                    Text("Edition(s)")
                        .italic()
                        .foregroundColor(Color.white)
                }
                VStack {
                    Text("\(user.role)")
                        .font(.title3)
                        .bold()
                        .foregroundColor(Color.white)
                    Text("Role")
                        .italic()
                        .foregroundColor(Color.white)
                }
                Spacer()
            }
            .padding()
            .background(Color("DarkBlue"))
            .cornerRadius(10)
            .padding(.horizontal)
            
            Spacer()

            // Affiche les champs éditables ou les détails du profil selon le mode d'édition.
            if isEditing {
                EditableField(title: "Pseudo", placeholder: "Pseudo", text: $viewModel.pseudo)
                EditableField(title: "E-mail", placeholder: "E-mail", text: $viewModel.email)
                EditableField(title: "Adresse", placeholder: "Adresse", text: $viewModel.postalAdress)
                EditableField(title: "Téléphone", placeholder: "Téléphone", text: $viewModel.telephone)
                EditableField(title: "Association", placeholder: "Association", text: $viewModel.association)
            } else {
                Divider()
                ProfileDetail(title: "Pseudo", value: viewModel.pseudo)
                Divider()
                ProfileDetail(title: "E-mail", value: viewModel.email)
                Divider()
                ProfileDetail(title: "Adresse", value: viewModel.postalAdress)
                Divider()
                ProfileDetail(title: "Téléphone", value: viewModel.telephone)
                Divider()
                ProfileDetail(title: "Association", value: viewModel.association)
                Divider()
            }
            
            Spacer()
        }
    }
}

// AvatarView affiche l'avatar de l'utilisateur.
struct AvatarView: View {
    var user: User

    var body: some View {
        ZStack {
            Circle()
                .fill(Color("BleuClair"))
                .frame(width: 100, height: 100)
            Text(user.firstName.prefix(1))
                .font(.title)
                .foregroundColor(.white)
        }
        .padding(.bottom, 20)
    }
}

// ProfileDetail affiche un détail spécifique du profil de l'utilisateur.
struct ProfileDetail: View {
    var title: String
    var value: String

    var body: some View {
        HStack {
            Text(title)
                .font(.title3)
                .bold()
                .foregroundColor(Color("DarkBlue"))
            Text(value)
                .italic()
                .foregroundColor(Color("DarkBlue"))
            Spacer()
        }
    }
}

// EditableField affiche un champ éditable pour le profil de l'utilisateur.
struct EditableField: View {
    var title: String
    var placeholder: String
    @Binding var text: String

    var body: some View {
        HStack {
            Text(title)
                .font(.title3)
                .bold()
                .foregroundColor(Color("DarkBlue"))
            TextField(placeholder, text: $text)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }
    }
}

// ProfilsView_Preview est un aperçu de la vue de profil pour l'interface de prévisualisation.
struct ProfilsView_Preview: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
