// FestivalEnCoursView représente une vue qui affiche les détails d'un festival en cours.

import SwiftUI

// FestivalEnCoursView affiche les détails d'un festival en cours.
struct FestivalEnCoursView: View {
    // View model pour gérer les données du festival en cours.
    @StateObject var viewModel = FestivalEnCoursViewModel()

    var body: some View {
        VStack {
            // Affiche un indicateur de chargement si les données sont en cours de chargement.
            if viewModel.isLoading {
               SkeletonCellView()
                    .padding()
            } else if let festival = viewModel.festival {
                // Affiche le nom et la date du festival.
                VStack(alignment: .center, spacing: 10) {
                    // Permet de naviguer vers la liste des jeux associée au festival.
                    NavigationLink(destination: ListeJeuView()) {
                        Text(festival.nom)
                            .font(.title2)
                            .bold()
                            .foregroundColor(Color("DarkBlue"))
                    }
                    Text(" \(festival.date)")
                        .font(.body)
                        .foregroundColor(.black)
                        .italic()
                }
                
                // Affiche un indicateur si l'utilisateur est inscrit au festival.
                if viewModel.isInscrit {
                    Image(systemName: "person.crop.circle.badge.checkmark")
                        .foregroundColor(Color("Vert"))
                        .padding()
                        .imageScale(.large)
                } else {
                    // Permet à l'utilisateur de s'inscrire au festival.
                    Button(action: {
                        viewModel.inscrireAuFestival()
                    }) {
                        Text("S'inscrire")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 150) // Largeur fixe
                            .background(Color("DarkBlue"))
                            .cornerRadius(8)
                            .shadow(color: .gray, radius: 3, x: 0, y: 2)
                    }
                }
            }
        }
        .onAppear {
            // Charge les données du festival en cours lors de l'affichage de la vue.
            viewModel.fetchFestivalData()
        }
    }
}

// FestivalEnCoursView_Previews fournit un aperçu de FestivalEnCoursView.
struct FestivalEnCoursView_Previews: PreviewProvider {
    static var previews: some View {
        FestivalEnCoursView()
    }
}
