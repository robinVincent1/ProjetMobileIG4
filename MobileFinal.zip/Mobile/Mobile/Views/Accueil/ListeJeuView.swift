// ContentView.swift
//
// Cette vue affiche une liste de jeux avec un menu déroulant permettant de sélectionner un espace.
// Les jeux sont chargés à partir d'un fichier CSV et affichés sous forme de cellules personnalisées.

import SwiftUI

// ListeJeuView est la vue principale qui affiche la liste des jeux.
struct ListeJeuView: View {
    // ViewModel pour gérer la logique métier et les données.
    @StateObject var viewModel = ListeJeuViewModel()
    // Variable pour stocker la sélection du menu déroulant.
    @State var dropDown = "Tous"
    // Booléen pour afficher ou masquer le menu déroulant.
    @State var showdropdown = true
    
    var body: some View {
        VStack {
            // Affiche une vue de chargement si les données sont en cours de chargement.
            if viewModel.isLoading {
                SkeletonCellView()
            } else if !viewModel.csv.isEmpty {
                if showdropdown {
                    // Menu déroulant pour sélectionner l'espace.
                    Menu {
                        ForEach(viewModel.listeEspace, id: \.self) { espace in
                            Button(action: {
                                dropDown = espace.planZone
                                // Mettre à jour les jeux en fonction de l'espace sélectionné.
                                viewModel.fetchCsv(zone: espace.planZone)
                            }, label: {
                                Text(espace.planZone)
                            })
                        }
                    } label: {
                        HStack {
                            Text("\(dropDown)")
                            Image(systemName: "pencil.circle")
                        }
                        .foregroundColor(Color("DarkBlue"))
                        .bold()
                        .font(.title2)
                        .padding()
                    }
                    .padding()
                }

                VStack {
                    NavigationView {
                        // Liste des jeux.
                        List(viewModel.csv) { jeu in
                            JeuCell(jeu: jeu)
                        }
                    }
                }
            }
        }
        .onAppear {
            // Chargement des espaces et des jeux au chargement de la vue.
            viewModel.fetchEspace()
            viewModel.fetchCsv(zone: dropDown)
        }
    }
}

// JeuCell représente une cellule dans la liste des jeux.
struct JeuCell: View {
    let jeu: Csv
    @State var showJeu : Bool = false
    
    var body: some View {
        VStack {
            // Bouton pour afficher les détails du jeu dans une feuille modale.
            Button(action: {
                showJeu.toggle()
            }) {
                HStack {
                    // Affiche l'image du jeu avec un chargement asynchrone.
                    AsyncImage(url: URL(string: jeu.logo)){
                        image in image.image?.resizable()
                    }
                    .cornerRadius(8)
                    .frame(width: 50, height: 50)
                    
                    VStack (alignment: .leading){
                        // Affiche le nom du jeu.
                        Text(jeu.nameGame)
                            .foregroundColor(Color("DarkBlue"))
                        // Affiche le nombre de joueurs si disponible.
                        if let nbplayer = jeu.nbPlayers {
                            Text("Nombre de joueur(s): \(String(describing: nbplayer))")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .italic()
                        }
                    }
                }
            }
            // Feuille modale pour afficher les détails complets du jeu.
            .sheet(isPresented: $showJeu) {
                JeuView(jeu: jeu, showJeu: $showJeu)
            }
        }
    }
}

// ListeJeuView_Previews fournit un aperçu de la vue ListeJeuView pour la prévisualisation.
struct ListeJeuView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ListeJeuView()
            ListeJeuView()
                .environment(\.colorScheme, .dark)
            ListeJeuView()
                .environment(\.sizeCategory, .extraExtraExtraLarge)
        }
    }
}
