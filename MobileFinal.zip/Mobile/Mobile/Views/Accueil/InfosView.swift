// La vue InfosView affiche une liste horizontale d'informations.
import SwiftUI

struct InfosView: View {
    // ViewModel pour gérer les données et la logique de la vue
    @StateObject var viewModel = InfosViewModel()

    var body: some View {
        VStack {
            // Affichage d'un indicateur de chargement si les données sont en cours de chargement
            if viewModel.isLoading {
                SkeletonCellView()
            } else if !viewModel.infos.isEmpty { // Affichage des informations si elles existent
                // ScrollView horizontale pour afficher les informations défilantes
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        // Boucle sur les informations pour les afficher
                        ForEach(viewModel.infos, id: \.idInfos) { infoItem in
                            // Affichage de chaque vue d'information à l'aide de CourseView
                            CourseView(title: infoItem.titre, image: "", description: infoItem.description, color: Color("Vert"), shadowColor: Color.gray)
                        }
                    }
                    .padding()
                }
            }
        }
        .onAppear {
            // Appel à la fonction pour récupérer les informations au chargement de la vue
            viewModel.fetchInfos()
        }
    }
}

// Vue CourseView pour afficher chaque élément d'information
struct CourseView: View {
    var title = "Build an app with SwiftUI" // Titre par défaut
    var image = "Illustration1" // Image par défaut
    var description = "" // Description par défaut
    var color = Color.gray // Couleur de fond par défaut
    var shadowColor = Color("backgroundShadow3") // Couleur de l'ombre par défaut

    var body: some View {
        VStack(alignment: .leading) {
            // Titre de l'information
            Text(title)
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.white)
                .padding(30)
                .lineLimit(4)

            // Description de l'information
            Text(description)
                .font(.title3)
                .foregroundColor(.white)
                .padding(30)
                .lineLimit(4)
        }
        .background(color) // Fond coloré
        .cornerRadius(30) // Coins arrondis
        .frame(width: 246, height: 360) // Taille fixe
        .shadow(color: shadowColor, radius: 20, x: 0, y: 20) // Ombre
    }
}

// Modèle de données pour chaque élément d'information
struct Course: Identifiable {
    var id = UUID()
    var title: String
    var image: String
    var color: Color
    var shadowColor: Color
    var description: String
}

// Aperçu de la vue InfosView
struct InfosView_Previews: PreviewProvider {
    static var previews: some View {
        InfosView()
    }
}
