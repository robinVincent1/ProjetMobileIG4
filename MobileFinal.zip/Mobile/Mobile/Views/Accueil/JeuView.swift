// JeuView affiche les détails d'un jeu spécifique.
import SwiftUI

struct JeuView: View {
    let jeu: Csv // Le jeu à afficher
    @Binding var showJeu: Bool // Indicateur de visibilité de la vue

    var body: some View {
        ScrollView {
            VStack {
                // Bouton pour masquer la vue de détails du jeu
                Button(action: {
                    showJeu.toggle()
                }) {
                    Image(systemName: "arrow.down.app")
                        .foregroundColor(Color("Vert"))
                        .padding()
                        .font(.system(size: 30)) // Définir une taille de police plus grande (par exemple 24 points)
                }
                // Image du jeu
                AsyncImage(url: URL(string: jeu.logo)) { image in
                    image.image?
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                }
                .frame(width: 200, height: 200)
                .padding(.horizontal, 20)
            }
            
            // Détails du jeu
            VStack(spacing: 20) {
                // Nom du jeu
                HStack {
                    Text(jeu.nameGame)
                        .font(.title)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                        .padding(.top, 20)
                        .foregroundColor(Color("DarkBlue"))
                }
                .padding()
                
                // Informations sur le jeu
                VStack(alignment: .leading, spacing: 10) {
                    Divider()
                    InfoRow(title: "Auteur", value: jeu.author ?? "")
                    Divider()
                    InfoRow(title: "Nombre de joueurs", value: jeu.nbPlayers ?? "")
                    Divider()
                    InfoRow(title: "Âge minimum", value: jeu.minAge ?? "")
                    Divider()
                    VStack {
                        Text("Description")
                            .foregroundColor(Color("DarkBlue"))
                            .font(.title3)
                        Spacer()
                        Text(jeu.description ?? "")
                            .italic()
                    }
                    Divider()
                }
                .padding(.horizontal, 20)
                
                Spacer()
            }
            .padding(.bottom, 20)
        }
    }
}

// InfoRow affiche une ligne d'informations avec un titre et une valeur.
struct InfoRow: View {
    let title: String // Titre de l'information
    let value: String // Valeur de l'information
    
    var body: some View {
        HStack {
            Text(title)
                .foregroundColor(Color("DarkBlue"))
                .font(.title3)
            Spacer()
            Text(value)
                .italic()
        }
    }
}
