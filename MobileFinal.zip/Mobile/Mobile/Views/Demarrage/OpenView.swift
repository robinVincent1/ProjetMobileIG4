// ContentView.swift
// SwiftUIProject
//
// Créé par Cairocoders
//

import SwiftUI

// OpenView est une vue responsable de l'affichage d'une animation de chargement avant de montrer le contenu principal.
struct OpenView: View {
    
    // Variables d'état pour suivre la progression du chargement et si le chargement est terminé.
    @State var progress: CGFloat = 0
    @State var doneLoading: Bool = false
     
    var body: some View {
        ZStack {
            // Si le chargement est terminé, transition vers ContentView.
            if doneLoading {
                ContentView()
                    .transition(AnyTransition.opacity.animation(.easeInOut(duration: 1.0)))
            } else {
                // Sinon, affiche une animation de chargement en utilisant LoadingView.
                LoadingView(content: Image("Open")
                                        .resizable()
                                        .scaledToFit()
                                        .padding(.horizontal, 50),
                            progress: $progress)
                    // Ajouté pour simuler le chargement asynchrone des données.
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                            withAnimation {
                                self.progress = 0
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                                withAnimation {
                                    self.doneLoading = true
                                }
                            }
                        }
                    }
            }
        }
    }
}

// PreviewProvider pour OpenView.
struct OpenView_Previews: PreviewProvider {
    static var previews: some View {
        OpenView()
    }
}

// ScaledMaskModifier est un modificateur personnalisé qui met à l'échelle le masque fourni en fonction de la progression.
struct ScaledMaskModifier<Mask: View>: ViewModifier {
    
    var mask: Mask
    var progress: CGFloat
    
    // Appliquer le masque au contenu.
    func body(content: Content) -> some View {
        content
            .mask(GeometryReader(content: { geometry in
                self.mask.frame(width: self.calculateSize(geometry: geometry) * self.progress,
                                height: self.calculateSize(geometry: geometry) * self.progress,
                                alignment: .center)
            }))
    }
    
    // Calculer la taille maximale du masque.
    func calculateSize(geometry: GeometryProxy) -> CGFloat {
        if geometry.size.width > geometry.size.height {
            return geometry.size.width
        }
        return geometry.size.height
    }
}

// LoadingView affiche une animation de chargement avec une vue de contenu personnalisable.
struct LoadingView<Content: View>: View {
    
    var content: Content
    @Binding var progress: CGFloat
    @State var logoOffset: CGFloat = 0 // Décalage Y de l'animation
    
    var body: some View {
        content
            .modifier(ScaledMaskModifier(mask: Circle(), progress: progress))
            .offset(x: 0, y: logoOffset)
            .onAppear {
                // Animer la progression du chargement.
                withAnimation(Animation.easeInOut(duration: 1)) {
                    self.progress = 1.0
                }
                // Animer le décalage du logo avec une animation répétée.
                withAnimation(Animation.easeInOut(duration: 0.4).repeatForever(autoreverses: true)) {
                    self.logoOffset = 10
                }
            }
    }
}
