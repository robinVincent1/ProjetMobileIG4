// ContentView.swift
// ProjetMobileIG4
//
// Créé par Robin Vincent le 06/03/2024.

import SwiftUI

// ContentView est la vue principale de l'application.
struct ContentView: View {
    @StateObject private var authManager = AuthManager()
    
    var body: some View {
        // Vérifier si l'utilisateur est authentifié pour afficher le contenu approprié.
        if authManager.isAuthenticated {
            // Afficher le contenu protégé de l'application avec une barre de navigation.
            NavBarView()
            Text("Bienvenue dans votre application")
                .onTapGesture {
                    authManager.logout()
                }
        } else {
            // Afficher l'écran de connexion si l'utilisateur n'est pas authentifié.
            Login(authManager: authManager)
        }
    }
}

// PreviewProvider pour ContentView.
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
