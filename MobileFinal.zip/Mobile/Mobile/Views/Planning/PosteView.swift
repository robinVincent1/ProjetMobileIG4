import SwiftUI

// La structure PosteView affiche les détails d'un poste avec une liste des créneaux disponibles.
struct PosteView: View {
    // Utilisation d'un StateObject pour gérer les données de la vue.
    @StateObject private var viewModel = PosteViewModel()
    // Récupération de l'environnement de présentation pour permettre le retour à l'écran précédent.
    @Environment(\.presentationMode) var presentationMode

    var id: Int // Identifiant du poste

    var body: some View {
        NavigationView {
            VStack {
                // En-tête de la vue
                HStack {
                    Image(systemName: "list.bullet.clipboard")
                    Text("Liste des différents postes")
                }
                .font(.title3)
                .bold()
                .padding()
                
                // Affichage de la date et de l'heure du poste
                VStack {
                    HStack {
                        Image(systemName: "calendar")
                        Text("\(viewModel.annee)/\(viewModel.mois)/\(viewModel.jour)")
                    }
                    HStack {
                        Image(systemName: "clock")
                        Text("\(viewModel.heuredebut)h-\(viewModel.heurefin)h")
                    }
                }
                
                // Liste des créneaux disponibles pour ce poste
                List(viewModel.creneaux, id: \.idCreneau) { creneau in
                    NavigationLink(destination: CreneauView(id: creneau.idCreneau, postViewModel: viewModel)) {
                        Text(creneau.titre)
                    }
                }
                
                // Ajout d'un bouton de retour dans la barre de navigation
                .navigationBarItems(leading: Button(action: {
                    presentationMode.wrappedValue.dismiss() // Dismiss la vue
                }) {
                    Image(systemName: "arrow.backward") // Icône de retour
                    Text("Retour") // Texte pour le bouton
                })
            }
        }
        .onAppear() {
            viewModel.fetchCreneaux(id: id) // Récupération des créneaux pour ce poste
        }
    }
}

// Aperçu de la vue
struct PosteView_Previews: PreviewProvider {
    static var previews: some View {
        PosteView(id: 1)
    }
}
