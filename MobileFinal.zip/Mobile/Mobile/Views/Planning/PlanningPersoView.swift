//
// PlanningPersoView.swift
// Mobile
//
// Created by Robin Vincent on 15/03/2024.
//

import SwiftUI
import UIKit

// Cette structure représente une vue SwiftUI qui intègre un contrôleur UIKit pour afficher le planning personnel.
struct PlanningPersoView: UIViewControllerRepresentable {
    
    // Cette méthode crée et retourne une instance du contrôleur UIKit correspondant à la vue.
    func makeUIViewController(context: Context) -> PlanningPersoController {
        return PlanningPersoController()
    }
    
    // Cette méthode est appelée lorsque des modifications doivent être apportées à la vue contrôleur UIKit.
    func updateUIViewController(_ uiViewController: PlanningPersoController, context: Context) {
        // Code de mise à jour du contrôleur UIKit, s'il y en a.
    }
    
    // Le type du contrôleur UIViewController associé à cette vue.
    typealias UIViewControllerType = PlanningPersoController
}
