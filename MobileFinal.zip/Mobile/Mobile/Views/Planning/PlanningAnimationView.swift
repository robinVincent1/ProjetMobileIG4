//
// SwiftUIView.swift
// Mobile
//
// Created by Robin Vincent on 13/03/2024.
//

import SwiftUI
import UIKit

// La structure PlanningAnimationView est une représentation UIViewController pour intégrer une animation de planning.
struct PlanningAnimationView: UIViewControllerRepresentable {
    
    // La méthode makeUIViewController crée et renvoie une instance de PlanningAnimationController.
    func makeUIViewController(context: Context) -> PlanningAnimationController {
        return PlanningAnimationController()
    }
    
    // La méthode updateUIViewController met à jour le contrôleur de vue avec les nouvelles données si nécessaire.
    func updateUIViewController(_ uiViewController: PlanningAnimationController, context: Context) {
        // code de mise à jour
    }
    
    // Le typealias UIViewControllerType définit le type de contrôleur de vue associé à cette représentation.
    typealias UIViewControllerType = PlanningAnimationController
}
