import SwiftUI

// La vue PlanningView permet de sélectionner et d'afficher différents types de plannings.
struct PlanningView: View {
    // État pour stocker le type de planning sélectionné
    @State private var planning = "Planning personnel"

    var body: some View {
        // Utilisation de NavigationView pour la navigation entre les vues
        NavigationView {
            VStack {
                // Affichage du titre du planning sélectionné
                Text(planning)
                    .foregroundColor(Color("DarkBlue")) // Couleur du texte
                    .font(.title) // Taille de la police
                    .bold() // Texte en gras
                
                // Affichage de la vue correspondant au planning sélectionné
                if planning == "Planning personnel" {
                    PlanningPersoView() // Vue du planning personnel
                } else if planning == "Planning général" {
                    PlanningGeneralView() // Vue du planning général
                } else {
                    PlanningAnimationView() // Vue du planning des animations
                }
            }
            // Ajout d'une barre d'outils pour la sélection du planning
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    // Menu déroulant pour sélectionner le type de planning
                    Menu("Plannings") {
                        Button("Personnel") {
                            planning = "Planning personnel"
                        }
                        Button("Général") {
                            planning = "Planning général"
                        }
                        Button("Jeux") {
                            planning = "Planning jeux"
                        }
                    }
                    .foregroundColor(Color.red) // Couleur du texte du menu
                    .bold() // Texte en gras
                }
            }
        }
    }
}

// Aperçu de la vue PlanningView
struct PlanningView_Previews: PreviewProvider {
    static var previews: some View {
        PlanningView()
    }
}
