import SwiftUI

// La structure CircularProgressView définit une vue personnalisée pour afficher une barre de progression circulaire avec des options de personnalisation.
public struct CircularProgressView: View {
    
    // MARK: Required variables
    var count: Int // La valeur actuelle de la progression
    var total: Int // La valeur totale de la progression
    var progress: CGFloat // Le progrès en pourcentage (0.0 - 1.0)
    
    // MARK: Optional variables
    var fontOne: Font // Police pour la valeur actuelle
    var fontTwo: Font // Police pour la valeur totale
    var colorOne: Color // Couleur pour la valeur actuelle
    var colorTwo: Color // Couleur pour la valeur totale
    var fill: AnyShapeStyle // Remplissage de la barre de progression
    var lineWidth: CGFloat // Largeur de la ligne de la barre de progression
    var lineCap: CGLineCap // Style de terminaison de la ligne de la barre de progression
    var showText: Bool // Indique si le texte au centre doit être affiché
    var showBottomText: Bool // Indique si le texte au bas du centre doit être affiché
    
    // MARK: Init
    public init(count: Int,
                total: Int,
                progress: CGFloat,
                fontOne: Font = Font.system(size: 75, weight: .bold, design: .rounded),
                fontTwo: Font = Font.system(size: 25, weight: .bold, design: .rounded),
                colorOne: Color = Color.primary,
                colorTwo: Color = Color.gray,
                fill: LinearGradient = LinearGradient(gradient: Gradient(colors: [Color.green, Color.blue]), startPoint: .top, endPoint: .bottom),
                lineWidth: CGFloat = 25.0,
                lineCap: CGLineCap = CGLineCap.round,
                showText: Bool = true,
                showBottomText: Bool = true) {
        self.count = count
        self.total = total
        self.progress = progress
        self.fontOne = fontOne
        self.fontTwo = fontTwo
        self.colorOne = colorOne
        self.colorTwo = colorTwo
        self.fill = AnyShapeStyle(fill)
        self.lineWidth = lineWidth
        self.lineCap = lineCap
        self.showText = showText
        self.showBottomText = showBottomText
    }
    
    // MARK: View
    public var body: some View {
        ZStack {
            // Ligne de fond pour la barre de progression
            Circle()
                .stroke(lineWidth: lineWidth)
                .opacity(0.3)
                .foregroundColor(Color.secondary)
            
            // Cercle de progression
            Circle()
                .trim(from: 0.0, to: CGFloat(min(self.progress, 1.0)))
                .stroke(fill ,style: StrokeStyle(lineWidth: lineWidth, lineCap: lineCap, lineJoin: .round))
                .rotationEffect(Angle(degrees: 270.0))
                .animation(.linear, value: progress)
            
            if showText {
                // Texte au centre
                VStack {
                    // Valeur actuelle
                    Text("\(count)")
                        .font(fontOne)
                        .foregroundColor(colorOne)
                    if showBottomText {
                        // Valeur totale
                        Text("/ \(total)")
                            .font(fontTwo)
                            .foregroundColor(colorTwo)
                    }
                }
            }
        }
    }
}
