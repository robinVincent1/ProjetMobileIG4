import SwiftUI

// Cette vue affiche les détails d'un créneau, permettant à l'utilisateur de s'inscrire ou de se désinscrire.
struct CreneauView: View {
    @Environment(\.presentationMode) var presentationMode
    @StateObject var viewModel = CreneauViewModel() // View model pour la récupération des données du créneau
    var id: Int // Identifiant du créneau
    var postViewModel : PosteViewModel // View model pour les données du poste associé
    
    // Calcul de la progression en fonction du nombre d'inscrits et de la capacité maximale du créneau
    var progress: CGFloat {
        guard let creneau = viewModel.creneau else { return 0 }
        let progress = CGFloat(creneau.nb_inscrit + creneau.nb_inscrit_flexible) / CGFloat(creneau.nb_max)
        return progress
    }
    
    var body: some View {
        NavigationView {
            VStack {
                if let creneau = viewModel.creneau {
                    // Titre du créneau
                    Text("\(creneau.titre)")
                        .padding()
                        .font(.title)
                        .bold()
                    
                    // Vue circulaire de progression
                    CircularProgressView(count: creneau.nb_inscrit + creneau.nb_inscrit_flexible, total: creneau.nb_max, progress: progress, fill: viewModel.CircleColor(percentage:progress))
                        .padding(EdgeInsets(top: 20, leading: 50, bottom: 12, trailing: 50))
                    
                    Spacer()
                    
                    // Affichage du nombre d'inscrits flexibles
                    Text("Dont \(creneau.nb_inscrit_flexible) flexible(s)")
                        .bold()
                        .font(.title3)
                    
                    Spacer()
                    
                    // Boutons pour s'inscrire ou se désinscrire en fonction de l'état actuel de l'utilisateur
                    if let isInscrit = viewModel.isInscrit {
                        if !postViewModel.dejaInscrit {
                            if isInscrit == "non" {
                                // Bouton pour s'inscrire
                                Button(action: {
                                    viewModel.inscriptionBenevole(flexible: false)
                                    postViewModel.dejaInscrit = true
                                }) {
                                    HStack {
                                        Text("S'inscrire")
                                        Image(systemName: "person.fill.checkmark")
                                    }
                                    .padding()
                                }
                                .buttonStyle(FilledButtonStyle()) // Appliquer le style de bouton rempli
                                
                                // Bouton pour s'inscrire en tant que flexible
                                Button(action: {
                                    viewModel.inscriptionBenevole(flexible: true)
                                    postViewModel.dejaInscrit = true
                                }) {
                                    HStack {
                                        Text("S'inscrire (Flexible)")
                                        Image(systemName: "person.fill.questionmark")
                                    }
                                    .padding()
                                }
                                .buttonStyle(FilledButtonStyle()) // Appliquer le style de bouton rempli
                            } else if isInscrit == "oui" {
                                // Bouton pour se désinscrire
                                Button(action: {
                                    viewModel.desinscriptionBenevole(flexible: false)
                                    postViewModel.dejaInscrit = false
                                }) {
                                    HStack {
                                        Text("Se désinscrire")
                                        Image(systemName: "person.fill.xmark")
                                    }
                                    .padding()
                                }
                                .buttonStyle(FilledButtonStyle()) // Appliquer le style de bouton rempli
                            }  else if isInscrit == "flexible" {
                                // Bouton pour se désinscrire en tant que flexible
                                Button(action: {
                                    viewModel.desinscriptionBenevole(flexible: true)
                                    postViewModel.dejaInscrit = false
                                }) {
                                    HStack {
                                        Text("Se désinscrire")
                                        Image(systemName: "person.fill.xmark")
                                    }
                                    .padding()
                                }
                                .buttonStyle(FilledButtonStyle()) // Appliquer le style de bouton rempli
                            }
                        } else if postViewModel.dejaInscrit && (viewModel.isInscrit == "oui" || viewModel.isInscrit == "flexible") {
                            if viewModel.isInscrit == "oui" {
                                // Bouton pour se désinscrire
                                Button(action: {
                                    viewModel.desinscriptionBenevole(flexible: false)
                                    postViewModel.dejaInscrit = false
                                }) {
                                    HStack {
                                        Text("Se désinscrire")
                                        Image(systemName: "person.fill.xmark")
                                    }
                                    .padding()
                                }
                                .buttonStyle(FilledButtonStyle()) // Appliquer le style de bouton rempli
                            } else {
                                // Bouton pour se désinscrire en tant que flexible
                                Button(action: {
                                    viewModel.desinscriptionBenevole(flexible: true)
                                    postViewModel.dejaInscrit = false
                                }) {
                                    HStack {
                                        Text("Se désinscrire")
                                        Image(systemName: "person.fill.xmark")
                                    }
                                    .padding()
                                }
                                .buttonStyle(FilledButtonStyle()) // Appliquer le style de bouton rempli
                            }
                        }
                        Spacer()
                    } else {
                        // Indicateur de chargement pendant que les données sont récupérées
                        ProgressView()
                    }
                }
                
            }
            .onAppear {
                // Récupération des données du créneau au chargement de la vue
                viewModel.fetchCreneau(id: id)
            }
        }
    }
}

// Style pour les boutons remplis
struct FilledButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(8)
    }
}
