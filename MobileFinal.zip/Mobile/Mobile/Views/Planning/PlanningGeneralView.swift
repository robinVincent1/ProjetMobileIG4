//
// SwiftUIView.swift
// Mobile
//
// Created by Robin Vincent on 13/03/2024.
//

import SwiftUI
import UIKit

// Cette structure représente une vue SwiftUI qui utilise un UIViewController.
struct PlanningGeneralView: UIViewControllerRepresentable {
    
    // Cette méthode crée et retourne une instance de PlanningGeneralController.
    func makeUIViewController(context: Context) -> PlanningGeneralController {
        return PlanningGeneralController()
    }
    
    // Cette méthode permet de mettre à jour l'interface utilisateur de PlanningGeneralController.
    func updateUIViewController(_ uiViewController: PlanningGeneralController, context: Context) {
        // Code pour mettre à jour l'interface utilisateur
    }
    
    // Ce typealias spécifie le type de UIViewController utilisé dans cette représentation SwiftUI.
    typealias UIViewControllerType = PlanningGeneralController
}
