import SwiftUI

// Cette structure représente une vue détaillée pour afficher une question et ses réponses dans le forum.
struct QuestionDetailView: View {
    var question: Question // La question à afficher
    @State private var responseText: String = "" // Texte de la réponse
    var modelView: ForumViewModel // Le viewModel du forum

    var body: some View {
        VStack {
            Divider()

            // Affichage de la question
            Text(question.question)
                .padding()
                .bold()
                .font(.title2)
                .foregroundColor(Color("DarkBlue"))

            Divider()
            
            // Affichage du texte "Début de la conversation"
            Text("Début de la conversation")
                .italic()
                .foregroundStyle(Color.gray)

            VStack(alignment: .leading) {
                ScrollView {
                    // Boucle à travers les réponses à la question
                    ForEach(question.idReponse.reversed(), id: \.idReponse) { reponse in
                        HStack {
                            // Bouton de suppression de la réponse si l'utilisateur est le créateur de la question
                            if question.createur == modelView.user?.firstName ?? "" {
                                Button(action: {
                                    modelView.deleteReponse(reponseId: reponse.idReponse)
                                }) {
                                    Image(systemName: "minus.circle")
                                }
                            }
                            VStack {
                                AvatarForumView(createur: reponse.createur) // Affichage de l'avatar de l'utilisateur répondant
                                Text(reponse.createur) // Affichage du nom de l'utilisateur répondant
                                    .italic()
                            }
                            VStack(alignment: .leading, spacing: 10) {
                                // Affichage de la réponse avec une mise en forme spécifique
                                Text(reponse.reponse)
                                    .padding()
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(8)
                                    .frame(maxWidth: .infinity, alignment: .leading) // Alignement à gauche
                            }
                            .padding(.horizontal)
                        }
                    }
                    
                    VStack{
                        // Champ de texte pour la réponse de l'utilisateur
                        TextField("Votre réponse", text: $responseText)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                        
                        // Bouton pour envoyer la réponse
                        Button(action: {
                            // Action pour envoyer la réponse
                            modelView.sendReponse(createur: modelView.user?.firstName ?? "", responseText: responseText, questionId: question.idQuestion)
                            modelView.fetchQuestion() // Recharger les données de la question
                        }) {
                            Text("Répondre")
                            Image(systemName: "rectangle.and.pencil.and.ellipsis")
                        }
                        .padding()
                        .foregroundColor(.white)
                        .background(Color("Vert")) // Fond vert pour le bouton
                        .cornerRadius(8)
                    }
                }
            }

            Spacer()
        }
        .padding()
    }
}
