import SwiftUI
import Foundation

// Cette vue représente la vue principale du forum.
struct ForumView: View {
    @StateObject var viewModel = ForumViewModel() // ViewModel pour gérer les données du forum
    @State private var isPresentingNewQuestion = false // Booléen pour afficher la vue de nouvelle question
    @State var isDeleted: Bool = false // Booléen pour indiquer si la suppression est activée

    var body: some View {
        NavigationView {
            VStack {
                if viewModel.isLoading {
                    SkeletonCellView() // Afficher un indicateur de chargement si les données sont en cours de chargement
                } else if !viewModel.questions.isEmpty {
                    // Barre de navigation avec bouton pour ajouter une nouvelle question et titre du forum
                    HStack {
                        // Bouton pour activer/désactiver le mode suppression
                        if isDeleted {
                            Button(action: {
                                isDeleted = false
                            }) {
                                Image(systemName: "trash.slash")
                                    .foregroundColor(Color("BleuClair")) // Couleur de l'icône
                            }
                            .padding()
                        } else {
                            Button(action: {
                                isDeleted = true
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(Color("BleuClair")) // Couleur de l'icône
                            }
                            .padding()
                        }
                        
                        Spacer()
                        
                        // Titre du forum
                        Text("Forum")
                            .font(.title)
                            .padding()
                            .bold()
                            .foregroundColor(Color("DarkBlue")) // Couleur du texte

                        Spacer()
                        
                        // Bouton pour ajouter une nouvelle question
                        Button(action: {
                            isPresentingNewQuestion.toggle()
                        }) {
                            Image(systemName: "plus.app")
                                .imageScale(.large)
                                .foregroundColor(Color("BleuClair")) // Couleur de l'icône
                        }
                        .sheet(isPresented: $isPresentingNewQuestion) {
                            NewQuestionView(viewModel: viewModel) // Afficher la vue de nouvelle question lorsque le bouton est appuyé
                        }
                        .padding()
                    }
                    
                    NewsView() // Afficher les actualités du forum
                    
                    // Liste des questions du forum
                    List(viewModel.questions) { question in
                        HStack {
                            // Bouton pour supprimer la question
                            if isDeleted && (viewModel.user?.firstName ?? "" == question.createur) {
                                Button(action: {
                                    viewModel.deleteQuestion(questionId: question.idQuestion)
                                }) {
                                    Image(systemName: "minus.circle")
                                }
                            }
                            // Lien de navigation vers les détails de la question
                            NavigationLink(destination: QuestionDetailView(question: question, modelView: viewModel)) {
                                // Vue représentant l'avatar du créateur de la question
                                AvatarForumView(createur: question.createur)
                                VStack(alignment: .leading, spacing: 8) {
                                    // Titre de la question
                                    Text(question.objet)
                                        .font(.title2)
                                    
                                    // Texte de la question
                                    Text(question.question)
                                        .font(.headline)
                                        .foregroundColor(Color("DarkBlue")) // Couleur du texte
                                    
                                    // Créateur de la question
                                    Text("Par \(question.createur)")
                                        .font(.subheadline)
                                        .italic()
                                }
                            }
                        }
                    }
                } else {
                    Text("Aucune question disponible.") // Message affiché lorsque aucune question n'est disponible
                }
            }
            .onAppear {
                viewModel.fetchQuestion() // Appeler la fonction pour récupérer les questions du forum lors de l'affichage de la vue
            }
        }
    }
}

// Structure pour afficher l'avatar du créateur de la question
struct AvatarForumView: View {
    var createur: String // Nom du créateur de la question

    var body: some View {
        ZStack {
            Circle()
                .fill(Color("Vert")) // Couleur de l'avatar
                .frame(width: 30, height: 30)
            Text(createur.prefix(1).uppercased())
                .foregroundColor(.white) // Couleur du texte
                .bold()
        }
    }
}


struct ForumView_Previews: PreviewProvider {
    static var previews: some View {
        ForumView()
    }
}


