import SwiftUI

// Cette vue permet à l'utilisateur de poser une nouvelle question dans le forum.
struct NewQuestionView: View {
    @State private var question = "" // Texte de la question
    @State private var objet = "" // Objet de la question
    var viewModel: ForumViewModel // ViewModel du forum
    @Environment(\.presentationMode) var presentationMode // Environnement pour gérer la présentation de la vue
    
    var body: some View {
        VStack {
            Spacer()
            
            // Titre de la vue pour poser une question
            Text("Posez votre question")
                .font(.title)
                .padding()
                .bold()
                .foregroundColor(Color("DarkBlue")) // Couleur du texte
            
            // Champ de saisie pour l'objet de la question
            HStack {
                Image(systemName: "doc") // Icône représentant un document
                TextField("Objet", text: $objet)
                    .cornerRadius(8)
                    .padding(.horizontal)
                    .textFieldStyle(.roundedBorder) // Style du champ de texte
            }
            .padding()
            
            // Champ de saisie pour la question
            HStack {
                Image(systemName: "questionmark.bubble") // Icône représentant une bulle de question
                TextField("Question", text: $question)
                    .cornerRadius(8)
                    .textFieldStyle(.roundedBorder) // Style du champ de texte
            }
            .padding()
            
            // Bouton pour envoyer la question
            Button(action: {
                // Action pour soumettre la question en utilisant le ViewModel
                viewModel.sendQuestion(createur: viewModel.user?.firstName ?? "", question: question, objet: objet)
                presentationMode.wrappedValue.dismiss() // Fermer la vue une fois la question soumise
            }) {
                Text("Envoyer") // Texte du bouton
                Image(systemName: "paperplane") // Icône d'avion en papier pour envoyer
            }
            .padding()
            .foregroundColor(.white) // Couleur du texte
            .background(Color("Vert")) // Couleur de fond du bouton
            .cornerRadius(8) // Coins arrondis du bouton
            
            Spacer()
        }
    }
}
