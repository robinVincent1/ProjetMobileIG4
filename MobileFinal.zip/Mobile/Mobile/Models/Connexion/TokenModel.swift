// AuthenticationManager.swift

import Security
import SwiftUI

// Classe gérant l'authentification et la gestion du token d'authentification
class AuthenticationManager {
    
    // Singleton pour partager une instance unique de la classe dans toute l'application
    static let shared = AuthenticationManager()
    
    // Clé utilisée pour enregistrer et récupérer le token dans le trousseau d'accès
    private let tokenKey = "accessToken"
    
    //Clé utilisée pour enregistrer et récupérer l'id de l'user dans le trousseau de d'accès
    private let userIdKey = "userId"
    
    // Constructeur privé pour empêcher l'initialisation directe de la classe
    private init() {}
    
    
    // Fonction pour sauvegarder l'ID utilisateur dans le trousseau d'accès
    func saveIdUserToKeychain(idUser: String) {
        let keychainQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: userIdKey,
            kSecValueData as String: idUser.data(using: .utf8)!,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlocked
        ]
        
        // Vérifier d'abord si le token de l'utilisateur existe déjà dans le trousseau
        if retrieveUserIdFromKeychain() != nil {
            // Si le token de l'utilisateur existe déjà, supprimez-le d'abord
            print("id deja existant")
            deleteUserIdFromKeychain()
        }
        
        let status = SecItemAdd(keychainQuery as CFDictionary, nil)
        guard status == errSecSuccess else {
            print("Erreur lors de l'enregistrement de l'id dans le trousseau d'accès : \(status)")
            return
        }
        
        print("id enregistré avec succès dans le trousseau d'accès.")
    }


    
    //fonction pour récupérer l'id de l'user connecté
    func retrieveUserIdFromKeychain() -> String? {
        let keychainQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: userIdKey,
            kSecMatchLimit as String: kSecMatchLimitOne,
            kSecReturnData as String: true
        ]
        
        var dataTypeRef: AnyObject?
        let status = SecItemCopyMatching(keychainQuery as CFDictionary, &dataTypeRef)
        
        guard status == errSecSuccess, let data = dataTypeRef as? Data else {
            print("Erreur lors de la récupération de l'id depuis le trousseau d'accès : \(status)")
            return nil
        }
        
        return String(data: data, encoding: .utf8)
    }
    
    // Fonction pour supprimer l'ID utilisateur du trousseau d'accès
    func deleteUserIdFromKeychain() {
        let keychainQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: userIdKey
        ]

        let status = SecItemDelete(keychainQuery as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            print("Erreur lors de la suppression de l'ID utilisateur du trousseau d'accès : \(status)")
            return
        }

        print("ID utilisateur supprimé avec succès du trousseau d'accès.")
    }
    
    // Fonction pour enregistrer le token dans le trousseau d'accès
    func saveTokenToKeychain(token: String) {
        let keychainQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: tokenKey,
            kSecValueData as String: token.data(using: .utf8)!,
            kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlocked
        ]
        
        // Vérifier d'abord si le token de l'utilisateur existe déjà dans le trousseau
        if retrieveTokenFromKeychain() != nil {
            // Si le token de l'utilisateur existe déjà, supprimez-le d'abord
            deleteTokenFromKeychain()
        }
        
        let status = SecItemAdd(keychainQuery as CFDictionary, nil)
        guard status == errSecSuccess else {
            print("Erreur lors de l'enregistrement du token dans le trousseau d'accès : \(status)")
            return
        }
        
        print("Token enregistré avec succès dans le trousseau d'accès.")
    }
    
    // Fonction pour récupérer le token depuis le trousseau d'accès
    func retrieveTokenFromKeychain() -> String? {
        let keychainQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: tokenKey,
            kSecMatchLimit as String: kSecMatchLimitOne,
            kSecReturnData as String: true
        ]
        
        var dataTypeRef: AnyObject?
        let status = SecItemCopyMatching(keychainQuery as CFDictionary, &dataTypeRef)
        
        guard status == errSecSuccess, let data = dataTypeRef as? Data else {
            print("Erreur lors de la récupération du token depuis le trousseau d'accès : \(status)")
            return nil
        }
        
        return String(data: data, encoding: .utf8)
    }
    
    // fonction pour supprimer le token du trousseau
    func deleteTokenFromKeychain() {
        let keychainQuery: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: tokenKey
        ]

        let status = SecItemDelete(keychainQuery as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            print("Erreur lors de la suppression du token du trousseau d'accès : \(status)")
            return
        }

        print("Token supprimé avec succès du trousseau d'accès.")
    }

}
