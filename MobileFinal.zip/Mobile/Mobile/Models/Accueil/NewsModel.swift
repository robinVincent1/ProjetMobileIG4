//
//  NewsModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation


struct News: Codable {
    var idNews: Int // Identifiant de l'actualité
    var createur: String // Créateur de l'actualité
    var titre: String // Titre de l'actualité
    var description: String // Description de l'actualité
    var favori: Bool // Indique si l'actualité est marquée comme favorite
}

// Fonction pour récupérer les actualités à partir de l'API
func getNewsFromAPI(completion: @escaping (Result<[News], Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        completion(.failure(AuthenticationError.missingCredentials))
        return
    }
    
    // Déballage de l'optionnel
    let url = URL(string: "\(urlAPI)/news/fav")!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.failure(AuthenticationError.apiError))
            }
            return
        }
        
        do {
            let newsList = try JSONDecoder().decode([News].self, from: data)
            completion(.success(newsList))
        } catch {
            completion(.failure(error))
        }
    }.resume()
}



