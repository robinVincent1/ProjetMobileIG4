import Foundation

// Définition de la structure Festival conforme au modèle récupéré depuis l'API
struct Festival: Codable {
    var idFestival: Int // Identifiant du festival
    var nom: String // Nom du festival
    var date: String // Date du festival
    var nbReferent: Int // Nombre de référents du festival
    var nbRespoSoiree: Int // Nombre de responsables de soirée du festival
    var nbAccueilBenevole: Int // Nombre d'accueils de bénévoles du festival
    var nbBenevole: Int // Nombre total de bénévoles du festival
    var enCours: Bool // Indique si le festival est en cours
    var idPlanning: String // Identifiant du planning du festival
}

// Fonction pour récupérer le festival en cours depuis l'API
func getFestivalsFromAPI(completion: @escaping (Result<Festival, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        completion(.failure(AuthenticationError.missingCredentials))
        return
    }
    
    // Déballage de l'optionnel
    let url = URL(string: "\(urlAPI)/festival/enCours")! // Endpoint pour récupérer les festivals
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.failure(AuthenticationError.apiError))
            }
            return
        }
        
        do {
            let festivalsList = try JSONDecoder().decode(Festival.self, from: data)
            completion(.success(festivalsList))
        } catch {
            completion(.failure(error))
        }
    }.resume()
}

// Fonction pour inscrire l'utilisateur à un festival
func inscription(idFestival: Int) {
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    if let idUser = idUser {
        updateUserInAPI(userId: idUser, festivalId: idFestival, flexible: true) { result in
            switch result {
            case .success(let updatedUser):
                // Traiter l'utilisateur mis à jour
                print("Utilisateur mis à jour : \(updatedUser)")
            case .failure(let error):
                // Gérer l'erreur
                print("Erreur lors de la mise à jour de l'utilisateur : \(error)")
            }
        }
    }
}
