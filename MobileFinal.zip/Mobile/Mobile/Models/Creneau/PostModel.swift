//
//  PostModel.swift
//  Mobile
//
//  Created by Robin Vincent on 19/03/2024.
//

import Foundation


// Fonction pour récupérer les créneaux par horaire depuis l'API
func getCreneauxByHoraire(url: String, completion: @escaping ([Creneau]?) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    
    // Vérifier si l'ID utilisateur et le token sont disponibles
    guard let _ = idUser, let token = token else {
        // Gérer le cas où l'ID utilisateur ou le jeton n'est pas disponible
        completion(nil)
        return
    }
    
    // Créer une URL à partir de la chaîne fournie
    guard let newurl = URL(string: url) else {
        // Gérer le cas où l'URL est incorrecte
        completion(nil)
        return
    }
    
    // Créer une requête HTTP GET avec les en-têtes nécessaires
    var request = URLRequest(url: newurl)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Effectuer la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            completion(nil)
            return
        }
        
        do {
            // Décoder les données JSON en tableau de créneaux
            let creneaux = try JSONDecoder().decode([Creneau].self, from: data)
            completion(creneaux)
        } catch {
            // Gérer les erreurs de décodage JSON
            completion(nil)
        }
    }.resume()
}

