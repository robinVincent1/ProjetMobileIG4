import Foundation

// Structure de modèle pour représenter un créneau
struct Creneau: Codable {
    var idCreneau: Int
    var LigneId: Int
    var JourId: Int
    var HoraireId: Int
    var idPlanning: Int
    var date: String
    var ouvert: Bool
    var heure_debut: Int
    var heure_fin: Int
    var titre: String
    var nb_max: Int
    var nb_inscrit: Int
    var nb_inscrit_flexible: Int
    var ReferentId: Int
    var isAnimation: Int
}

// Fonction pour récupérer les créneaux depuis l'API
func getCreneauxFromAPI(isAnimation: Int, url: String) -> [Creneau]? {
    // Récupération du token et de l'ID utilisateur depuis le Keychain
    guard let _ = AuthenticationManager.shared.retrieveUserIdFromKeychain(),
          let token = AuthenticationManager.shared.retrieveTokenFromKeychain() else {
        return nil
    }
    
    // Création de l'URL à partir de la chaîne spécifiée
    guard let url = URL(string: url) else {
        return nil
    }
    
    var creneaux: [Creneau] = []
    
    // Création d'une requête HTTP GET avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    let semaphore = DispatchSemaphore(value: 0)
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        defer {
            semaphore.signal()
        }
        
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            return
        }
        
        do {
            // Décodage des données JSON en tableau de créneaux
            creneaux = try JSONDecoder().decode([Creneau].self, from: data)
        } catch {
            // Gérer les erreurs de décodage JSON
        }
    }.resume()
    
    _ = semaphore.wait(timeout: .distantFuture)
    
    return creneaux
}

// Fonction pour récupérer un créneau depuis l'API
func getCreneauFromAPI(url: String) -> Creneau? {
    // Récupération du token et de l'ID utilisateur depuis le Keychain
    guard let _ = AuthenticationManager.shared.retrieveUserIdFromKeychain(),
          let token = AuthenticationManager.shared.retrieveTokenFromKeychain() else {
        return nil
    }
    
    // Création de l'URL à partir de la chaîne spécifiée
    guard let url = URL(string: url) else {
        return nil
    }
    
    var creneau: Creneau?
    
    // Création d'une requête HTTP GET avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    let semaphore = DispatchSemaphore(value: 0)
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        defer {
            semaphore.signal()
        }
        
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            return
        }
        
        do {
            // Décodage des données JSON en objet Creneau
            creneau = try JSONDecoder().decode(Creneau.self, from: data)
        } catch {
            // Gérer les erreurs de décodage JSON
        }
    }.resume()
    
    _ = semaphore.wait(timeout: .distantFuture)
    
    return creneau
}

// Fonction pour vérifier si l'utilisateur est inscrit à un créneau
func getIsInscrit(url: String, completion: @escaping (String) -> Void) {
    // Récupération du token et de l'ID utilisateur depuis le Keychain
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain(),
          let _ = AuthenticationManager.shared.retrieveUserIdFromKeychain(),
          let url = URL(string: url) else {
        completion("erreur")
        return
    }
    
    // Création d'une requête HTTP GET avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            completion("erreur")
            return
        }
        
        if let stringValue = String(data: data, encoding: .utf8) {
            // Si la conversion en chaîne de caractères réussit, utilisez la valeur renvoyée par l'API
            completion(stringValue)
        } else {
            // Si la conversion échoue, renvoyez "erreur"
            completion("erreur")
        }
    }.resume()
}

// Fonction pour ajouter un utilisateur inscrit à un créneau
func AddCreneauBenevole(flexible: Int, idCreneau: Int, idUser: String, completion: @escaping (Result<Void, Error>) -> Void) {
    // Récupération du token depuis le Keychain
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain() else {
        return
    }
    
    // Création de l'URL pour l'ajout d'un utilisateur inscrit à un créneau
    let url = URL(string: "\(urlAPI)/creneau_benevole/")!
    
    // Création d'une requête HTTP POST avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Données à envoyer dans la requête
    let requestData: [String: Any] = [
        "idCreneau": idCreneau,
        "idUser": idUser,
        "flexible": flexible,
    ]
    
    do {
        // Encodage des données JSON à envoyer dans la requête
        request.httpBody = try JSONSerialization.data(withJSONObject: requestData)
    } catch {
        completion(.failure(error))
        return
    }
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            // Gérer les erreurs de requête ou de données
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        // Indiquer que l'opération s'est terminée avec succès
        completion(.success(()))
    }.resume()
}

// Fonction pour supprimer un utilisateur inscrit à un créneau
func RemoveCreneauBenevole(idCreneau: Int, idUser: String, completion: @escaping (Result<Void, Error>) -> Void) {
    // Récupération du token depuis le Keychain
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain() else {
        return
    }
    
    // Création de l'URL pour la suppression de l'utilisateur inscrit à un créneau
    let url = URL(string: "\(urlAPI)/creneau_benevole")!
    
    // Création d'une requête HTTP DELETE avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "DELETE"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Données à envoyer dans la requête
    let requestData: [String: Any] = [
        "idCreneau": idCreneau,
        "idUser": idUser
    ]
    
    do {
        // Encodage des données JSON à envoyer dans la requête
        request.httpBody = try JSONSerialization.data(withJSONObject: requestData)
    } catch {
        completion(.failure(error))
        return
    }
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            // Gérer les erreurs de requête ou de données
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        // Indiquer que l'opération s'est terminée avec succès
        completion(.success(()))
    }.resume()
}

// Fonction pour ajouter le nombre d'inscrits à un créneau
func AddNbInscrit(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    // Récupération du token depuis le Keychain
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain() else {
        return
    }
    
    // Création de l'URL pour ajouter le nombre d'inscrits à un créneau
    let url = URL(string: "\(urlAPI)/creneau/addnbinscrit/\(idCreneau)")!
    
    // Création d'une requête HTTP PUT avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            // Gérer les erreurs de requête ou de données
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        // Indiquer que l'opération s'est terminée avec succès
        completion(.success(()))
    }.resume()
}

// Fonction pour ajouter le nombre d'inscrits flexibles à un créneau
func AddNbInscritFlexible(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    // Récupération du token depuis le Keychain
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain() else {
        return
    }
    
    // Création de l'URL pour ajouter le nombre d'inscrits flexibles à un créneau
    let url = URL(string: "\(urlAPI)/creneau/addnbinscritflexible/\(idCreneau)")!
    
    // Création d'une requête HTTP PUT avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            // Gérer les erreurs de requête ou de données
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        // Indiquer que l'opération s'est terminée avec succès
        completion(.success(()))
    }.resume()
}

// Fonction pour supprimer le nombre d'inscrits à un créneau

func RemoveNbInscrit(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    // Récupération du token depuis le Keychain
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain() else {
        return
    }
    
    // Création de l'URL pour supprimer le nombre d'inscrits à un créneau
    let url = URL(string: "\(urlAPI)/creneau/subnbinscrit/\(idCreneau)")!
    
    // Création d'une requête HTTP PUT avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            // Gérer les erreurs de requête ou de données
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        // Indiquer que l'opération s'est terminée avec succès
        completion(.success(()))
    }.resume()
}

// Fonction pour supprimer le nombre d'inscrits flexibles à un créneau
func RemoveNbInscritFlexible(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    // Récupération du token depuis le Keychain
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain() else {
        return
    }
    
    // Création de l'URL pour supprimer le nombre d'inscrits flexibles à un créneau
    let url = URL(string: "\(urlAPI)/creneau/subnbinscritflexible/\(idCreneau)")!
    
    // Création d'une requête HTTP PUT avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            // Gérer les erreurs de requête ou de données
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        // Indiquer que l'opération s'est terminée avec succès
        completion(.success(()))
    }.resume()
}


