import Foundation

// Structure de modèle pour représenter les données d'un fichier CSV
struct Csv: Codable, Identifiable {
    var id: Int?
    var idJeu: String?
    var nameGame: String
    var author: String?
    var editor: String?
    var nbPlayers: String?
    var minAge: String?
    var duration: String?
    var type: String?
    var notice: String?
    var planZone: String?
    var volunteerZone: String?
    var idZone: String?
    var toAnimate: String?
    var received: String?
    var mechanisms: String?
    var themes: String?
    var tags: String?
    var description: String?
    var image: String?
    var logo: String
    var video: String?
}

// Structure de modèle pour représenter les données d'un espace
struct Espace: Codable, Hashable {
    var planZone: String
}

// Fonction pour récupérer les données CSV depuis l'API
func getCsvFromAPI(zone: String, completion: @escaping (Result<[Csv], Error>) -> Void) {
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain(),
         let _ = AuthenticationManager.shared.retrieveUserIdFromKeychain() else {
        return
    }
    
    var url: URL
    
    if zone == "Tous" {
        url = URL(string: "\(urlAPI)/csv/get")!
    } else {
        url = URL(string: "\(urlAPI)/csv/getjeu/\(zone)")!
    }
    
    // Création de la requête HTTP GET avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.failure(AuthenticationError.apiError))
            }
            return
        }
        
        do {
            // Décodage des données JSON en tableau de structures Csv
            let csv = try JSONDecoder().decode([Csv].self, from: data)
            completion(.success(csv))
        } catch {
            completion(.failure(error))
        }
    }.resume()
}

// Fonction pour récupérer les données des espaces depuis l'API
func getEspaceFromAPI(completion: @escaping (Result<[Espace], Error>) -> Void) {
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain(),
        let  _ = AuthenticationManager.shared.retrieveUserIdFromKeychain() else {
        return
    }
    
    let url = URL(string: "\(urlAPI)/csv/getallespace")!
    
    // Création de la requête HTTP GET avec les en-têtes nécessaires
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Exécution de la requête HTTP
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.failure(AuthenticationError.apiError))
            }
            return
        }
        
        do {
            // Décodage des données JSON en tableau de structures Espace
            let espaces = try JSONDecoder().decode([Espace].self, from: data)
            completion(.success(espaces))
        } catch {
            completion(.failure(error))
        }
    }.resume()
}
