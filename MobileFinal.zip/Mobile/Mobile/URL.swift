//
//  URL.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation

//url de l'api
var urlAPI : String = "http://localhost:8080"
