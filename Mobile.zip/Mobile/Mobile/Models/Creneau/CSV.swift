//
//  CSV.swift
//  Mobile
//
//  Created by Robin Vincent on 18/03/2024.
//

import Foundation

import Foundation

struct Csv: Codable, Identifiable {
    var id: Int?
    var idJeu: String?
    var nameGame: String
    var author: String?
    var editor: String?
    var nbPlayers: String?
    var minAge: String?
    var duration: String?
    var type: String?
    var notice: String?
    var planZone: String?
    var volunteerZone: String?
    var idZone: String?
    var toAnimate: String?
    var received: String?
    var mechanisms: String?
    var themes: String?
    var tags: String?
    var description: String?
    var image: String?
    var logo: String
    var video: String?
}

struct Espace : Codable, Hashable {
    var planZone: String
}

//fonction pour récupérer le csv dans l'api
func getCsvFromAPI(zone: String, completion: @escaping (Result<[Csv], Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    
    if let idUser = idUser {
        if let token = token {
            var url = URL(string: "\(urlAPI)/csv/get")!
            
            if zone != "Tous" {
                 url = URL(string: "\(urlAPI)/csv/getjeu/\(zone)")!
            }
            
            // Déballage de l'optionnel et utilisation de l'ID de l'utilisateur
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            
            URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, error == nil else {
                    if let error = error {
                        completion(.failure(error))
                    } else {
                        completion(.failure(AuthenticationError.apiError))
                    }
                    return
                }
                
                do {
                    let csv = try JSONDecoder().decode([Csv].self, from: data)
                    completion(.success(csv))
                } catch {
                    completion(.failure(error))
                }
            }.resume()
        }
    }
}



//fonction pour récupérer le csv dans l'api
func getEspaceFromAPI(completion: @escaping (Result<[Espace], Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    
    if let idUser = idUser {
        if let token = token {
            let url = URL(string: "\(urlAPI)/csv/getallespace")!
            // Déballage de l'optionnel et utilisation de l'ID de l'utilisateur
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            
            URLSession.shared.dataTask(with: request) { data, response, error in
                guard let data = data, error == nil else {
                    if let error = error {
                        completion(.failure(error))
                    } else {
                        completion(.failure(AuthenticationError.apiError))
                    }
                    return
                }
                
                do {
                    let csv = try JSONDecoder().decode([Espace].self, from: data)
                    completion(.success(csv))
                } catch {
                    completion(.failure(error))
                }
            }.resume()
        }
    }
}



