//
//  CreneauModel.swift
//  Mobile
//
//  Created by Robin Vincent on 16/03/2024.
//

import Foundation

import Foundation

struct Creneau : Codable {
    var idCreneau: Int
    var LigneId: Int
    var JourId: Int
    var HoraireId: Int
    var idPlanning: Int
    var date: String
    var ouvert: Bool
    var heure_debut: Int
    var heure_fin: Int
    var titre: String
    var nb_max: Int
    var nb_inscrit: Int
    var nb_inscrit_flexible: Int
    var ReferentId: Int
    var isAnimation: Int
}

func getCreneauxFromAPI(isAnimation: Int, url : String) -> [Creneau]? {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    guard let idUser = idUser, let token = token else {
        // Gérer le cas où l'ID utilisateur ou le jeton n'est pas disponible
        return nil
    }
    
    let url = URL(string: url)!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    var creneaux: [Creneau] = []

    
    let semaphore = DispatchSemaphore(value: 0)
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        defer {
            semaphore.signal()
        }
        
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            return
        }
        
        do {
            creneaux = try JSONDecoder().decode([Creneau].self, from: data)
        } catch {
            // Gérer les erreurs de décodage JSON
        }
    }.resume()
    
    _ = semaphore.wait(timeout: .distantFuture)

    return creneaux
}


func getCreneauFromAPI(url : String) -> Creneau? {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    
    guard let idUser = idUser, let token = token else {
        // Gérer le cas où l'ID utilisateur ou le jeton n'est pas disponible
        return nil
    }
    
    let url = URL(string: url)!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    var creneau: Creneau? = nil
    
    let semaphore = DispatchSemaphore(value: 0)
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        defer {
            semaphore.signal()
        }
        
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            return
        }
        
        do {
            creneau = try JSONDecoder().decode(Creneau.self, from: data)
        } catch {
            // Gérer les erreurs de décodage JSON
        }
    }.resume()
    
    _ = semaphore.wait(timeout: .distantFuture)
    return creneau
}


func getIsInscrit(url: String, completion: @escaping (String) -> Void) {
    guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain(),
          let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain(),
          let url = URL(string: url) else {
        // Gérer le cas où l'ID utilisateur, le jeton ou l'URL est incorrecte
        completion("erreur")
        return
    }
    
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            completion("erreur")
            return
        }
        
        if let stringValue = String(data: data, encoding: .utf8) {
            // Si la conversion en chaîne de caractères réussit, utilisez la valeur renvoyée par l'API
            completion(stringValue)
        } else {
            // Si la conversion échoue, renvoyez "erreur"
            completion("erreur")
        }
    }.resume()
}

func AddNbInscrit(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    print(idCreneau)
    let url = URL(string: "\(urlAPI)/creneau/addnbinscrit/\(idCreneau)")!
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        completion(.success(()))
    }.resume()
}

func AddNbInscritFlexible(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    print(idCreneau)
    let url = URL(string: "\(urlAPI)/creneau/addnbinscritflexible/\(idCreneau)")!
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        completion(.success(()))
    }.resume()
}

func AddCreneauBenevole(flexible: Int, idCreneau: Int, idUser: String, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    
    let url = URL(string: "\(urlAPI)/creneau_benevole/")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    let requestData: [String: Any] = [
        "idCreneau": idCreneau,
        "idUser": idUser,
        "flexible": flexible,
    ]
    
    do {
        request.httpBody = try JSONSerialization.data(withJSONObject: requestData)
    } catch {
        completion(.failure(error))
        return
    }
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        completion(.success(()))
    }.resume()
}


func RemoveNbInscrit(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    
    let url = URL(string: "\(urlAPI)/creneau/subnbinscrit/\(idCreneau)")!
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        completion(.success(()))
    }.resume()
}

func RemoveNbInscritFlexible(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    
    let url = URL(string: "\(urlAPI)/creneau/subnbinscritflexible/\(idCreneau)")!
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        completion(.success(()))
    }.resume()
}

func RemoveCreneauBenevole(idCreneau: Int, idUser: String, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    
    let url = URL(string: "\(urlAPI)/creneau_benevole")!
    var request = URLRequest(url: url)
    request.httpMethod = "DELETE"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    let requestData: [String: Any] = [
        "idCreneau": idCreneau,
        "idUser": idUser
    ]
    
    do {
        request.httpBody = try JSONSerialization.data(withJSONObject: requestData)
    } catch {
        completion(.failure(error))
        return
    }
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        completion(.success(()))
    }.resume()
}




