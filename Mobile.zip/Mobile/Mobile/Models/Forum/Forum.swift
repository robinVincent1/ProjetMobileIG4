//
//  Forum.swift
//  Mobile
//
//  Created by Robin Vincent on 20/03/2024.
//

import Foundation


struct Question: Codable, Identifiable {
    var idQuestion: Int
    var createur: String
    var objet: String
    var question: String
    var idReponse: [Reponse]

    // Déclarer une propriété unique comme identifiant
    var id: Int {
        idQuestion
    }

    // Initialisateur personnalisé pour Question
    init(idQuestion: Int, createur: String, objet: String, question: String, idReponse: [Reponse]) {
        self.idQuestion = idQuestion
        self.createur = createur
        self.objet = objet
        self.question = question
        self.idReponse = idReponse
    }
}


struct Reponse: Codable, Identifiable {
    var idReponse: Int
    var createur: String
    var reponse: String
    var questionId: String
    
    // Déclarer une propriété unique comme identifiant
    var id: Int {
        idReponse
    }

    // Initialisateur personnalisé pour Reponse
    init(idReponse: Int, createur: String, reponse: String, questionId: String) {
        self.idReponse = idReponse
        self.createur = createur
        self.reponse = reponse
        self.questionId = questionId
    }
}

struct NouvelleReponse: Codable {
    var createur: String
    var reponse: String
}


// Fonction pour récupérer les questions à partir de l'API
func getQuestionsFromAPI(completion: @escaping (Result<[Question], Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        completion(.failure(AuthenticationError.missingCredentials))
        return
    }
    
    // Déballage de l'optionnel
    let url = URL(string: "\(urlAPI)/qr")!
    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.failure(AuthenticationError.apiError))
            }
            return
        }
        
        do {
            let questionList = try JSONDecoder().decode([Question].self, from: data)
            completion(.success(questionList))
        } catch {
            completion(.failure(error))
        }
    }.resume()
}

// fonction pour envoyer une reponsse
func postResponseToAPI(createur: String, responseText: String, questionId: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        completion(.failure(AuthenticationError.missingCredentials))
        return
    }
    
    let url = URL(string: "\(urlAPI)/qr/reponse/\(questionId)")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Création des données à envoyer
    let requestData: [String: Any] = [
        "createur": createur,
        "reponse": responseText
    ]
    
    do {
        // Encodage des données
        let jsonData = try JSONSerialization.data(withJSONObject: requestData)
        request.httpBody = jsonData
        
        // Envoi de la requête
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let _ = data, error == nil else {
                if let error = error {
                    completion(.failure(error))
                }
                return
            }
            
            completion(.success(()))
        }.resume()
    } catch {
        completion(.failure(error))
    }
}


// fonction pour envoyer une question
func postQuestionToAPI(createur: String, question: String, objet: String, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        completion(.failure(AuthenticationError.missingCredentials))
        return
    }
    
    let url = URL(string: "\(urlAPI)/qr")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    // Création des données à envoyer
    let requestData: [String: Any] = [
        "question": question,
        "objet": objet,
        "createur": createur
    ]
    
    do {
        // Encodage des données
        let jsonData = try JSONSerialization.data(withJSONObject: requestData)
        request.httpBody = jsonData
        
        // Envoi de la requête
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let _ = data, error == nil else {
                if let error = error {
                    completion(.failure(error))
                }
                return
            }
            
            completion(.success(()))
        }.resume()
    } catch {
        completion(.failure(error))
    }
}

// fonction pour supprimer une question
func deleteQuestionToAPI(questionId: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        completion(.failure(AuthenticationError.missingCredentials))
        return
    }
    
    let url = URL(string: "\(urlAPI)/qr/\(questionId)")!
    var request = URLRequest(url: url)
    request.httpMethod = "DELETE"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    do {
    
        // Envoi de la requête
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let _ = data, error == nil else {
                if let error = error {
                    completion(.failure(error))
                }
                return
            }
            
            completion(.success(()))
        }.resume()
    } catch {
        completion(.failure(error))
    }
}


// fonction pour supprimer une reponse
func deleteReponseToAPI(reponseId: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        completion(.failure(AuthenticationError.missingCredentials))
        return
    }
    
    let url = URL(string: "\(urlAPI)/qr/reponse/\(reponseId)")!
    var request = URLRequest(url: url)
    request.httpMethod = "DELETE"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    do {
    
        // Envoi de la requête
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let _ = data, error == nil else {
                if let error = error {
                    completion(.failure(error))
                }
                return
            }
            
            completion(.success(()))
        }.resume()
    } catch {
        completion(.failure(error))
    }
}
