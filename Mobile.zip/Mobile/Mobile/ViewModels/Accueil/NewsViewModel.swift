//
//  NewsViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation

import Foundation

class NewsViewModel: ObservableObject {
    @Published var news: [News] = []
    @Published var errorMessage = ""
    @Published var isLoading = false

    func fetchNews() {
        isLoading = true
        getNewsFromAPI { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let newsList):
                    self.news = newsList
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
}

