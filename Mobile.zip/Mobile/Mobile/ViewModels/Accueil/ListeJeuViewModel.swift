//
//  JeuViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 18/03/2024.
//

import Foundation

class ListeJeuViewModel: ObservableObject {
    @Published var csv: [Csv] = []
    @Published var errorMessage = ""
    @Published var isLoading = false
    @Published var listeEspace : [Espace] = []

    func fetchCsv(zone: String) {
        isLoading = true
        getCsvFromAPI(zone: zone) { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let fetchedCsv):
                    self.csv = fetchedCsv
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    func fetchEspace() {
        isLoading = true
        getEspaceFromAPI { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let fetchedCsv):
                    self.listeEspace = fetchedCsv
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    
}
