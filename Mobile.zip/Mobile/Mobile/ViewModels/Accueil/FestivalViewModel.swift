//
//  FestivalViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation


import Foundation

class FestivalEnCoursViewModel: ObservableObject {
    @Published var festival: Festival?
    @Published var isLoading = false
    @Published var errorMessage = ""
    @Published var user: User?
    @Published var isInscrit = false

    func fetchFestivalData() {
        isLoading = true
        getUserFromAPI { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let user):
                    self.user = user
                    self.getFestival()
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                    self.isLoading = false
                }
            }
        }
    }

    private func getFestival() {
        getFestivalsFromAPI { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let festival):
                    self.festival = festival
                    self.isLoading = false
                        if let userId = self.user?.idFestival {
                            self.isInscrit = String(festival.idFestival) == userId
                        }
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                    self.isLoading = false
                }
            }
        }
    }



    func inscrireAuFestival() {
        guard let festivalId = festival?.idFestival else { return }
        inscription(idFestival: festivalId)
        self.isInscrit = true
    }
}


