//
//  InfosViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import Foundation


import Foundation

class InfosViewModel: ObservableObject {
    @Published var infos: [Infos] = []
    @Published var errorMessage = ""
    @Published var isLoading = false

    func fetchInfos() {
        isLoading = true
        getInfosFromAPI { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let infosList):
                    self.infos = infosList
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
}


