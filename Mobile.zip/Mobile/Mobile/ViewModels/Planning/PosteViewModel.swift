//
//  PosteViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 17/03/2024.
//

import Foundation

class PosteViewModel: ObservableObject {
    @Published var creneaux: [Creneau] = []
    @Published var date :  String = ""
    @Published var annee : String = ""
    @Published var mois : String = ""
    @Published var jour: String = ""
    @Published var heuredebut : Int = 0
    @Published var heurefin: Int = 0
    @Published var dejaInscrit = false
    
    func fetchCreneaux(id: Int) {
        guard let creneau = getCreneauFromAPI(url: "\(urlAPI)/creneau/getbyid/\(id)") else {
            return
        }
        // Convertir les valeurs d'heure_debut et heure_fin en chaînes de caractères
        let heureDebutString = String(creneau.heure_debut)
        let heureFinString = String(creneau.heure_fin)
        
        // Utiliser les chaînes de caractères converties dans l'URL
        getCreneauxByHoraire(url: "\(urlAPI)/creneau/getbydateandhoraire/\(creneau.date)/\(heureDebutString)/\(heureFinString)/\(creneau.isAnimation)") { fetchedCreneaux in
            if let fetchedCreneaux = fetchedCreneaux {
                DispatchQueue.main.async {
                    self.creneaux = fetchedCreneaux
                    if !self.creneaux.isEmpty {
                        self.date = self.creneaux[0].date
                        let dateAr = self.date.components(separatedBy: "-")
                        self.annee = dateAr[0]
                        self.mois = dateAr[1]
                        self.jour = dateAr[2]
                        self.heuredebut = self.creneaux[0].heure_debut
                        self.heurefin = self.creneaux[0].heure_fin
                    }
                }
            } else {
                self.creneaux = [] // Ou toute autre logique de gestion d'erreur
            }
            let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
            for c in self.creneaux {
                // Appel de la fonction getIsInscrit
                if let idUser = idUser {
                    getIsInscrit(url: "\(urlAPI)/creneau_benevole/isInscrit/\(String(describing: idUser))/\(c.idCreneau)") { stringValue in
                        // Gérer la réponse reçue dans la complétion
                        // Vous pouvez faire d'autres traitements en fonction de la valeur reçue
                        print(stringValue)
                        if stringValue == "oui" || stringValue == "flexible" {
                            self.dejaInscrit = true
                        }
                    }
                }
            }
        }
        
    }
}



