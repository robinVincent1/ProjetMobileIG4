//
//  PosteViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 17/03/2024.
//

import Foundation

func getCreneauxByHoraire(url: String, completion: @escaping ([Creneau]?) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
    
    guard let idUser = idUser, let token = token else {
        // Gérer le cas où l'ID utilisateur ou le jeton n'est pas disponible
        completion(nil)
        return
    }
    
    guard let newurl = URL(string: url) else {
        // Gérer le cas où l'URL est incorrecte
        completion(nil)
        return
    }
    
    var request = URLRequest(url: newurl)
    request.httpMethod = "GET"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        guard let data = data, error == nil else {
            // Gérer les erreurs de requête ou de données
            completion(nil)
            return
        }
        
        do {
            let creneaux = try JSONDecoder().decode([Creneau].self, from: data)
            completion(creneaux)
        } catch {
            // Gérer les erreurs de décodage JSON
            completion(nil)
        }
    }.resume()
}


