//
//  CreneauViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 17/03/2024.
//

import Foundation
import SwiftUI


class CreneauViewModel: ObservableObject {
    @Published var creneau: Creneau?
    @Published var isInscrit: String?
    
    func fetchCreneau(id: Int) {
        creneau = getCreneauFromAPI(url: "\(urlAPI)/creneau/getbyid/\(id)")
        guard let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain(), let creneauId = creneau?.idCreneau else {
            return
        }
        
        getIsInscrit(url: "\(urlAPI)/creneau_benevole/isInscrit/\(idUser)/\(creneauId)") { stringValue in
            self.isInscrit = stringValue
        }
    }
    

    
    func inscriptionBenevole(flexible: Bool) {
        guard let creneau = creneau else {
            print("Erreur: Le créneau n'est pas défini.")
            return
        }
        
        let userId = AuthenticationManager.shared.retrieveUserIdFromKeychain()
        
        guard let userId = userId else {
            print("Erreur: Impossible de récupérer l'ID de l'utilisateur.")
            return
        }
        
        if flexible {
            self.creneau!.nb_inscrit_flexible += 1
            AddNbInscritFlexible(idCreneau: self.creneau!.idCreneau) { result in
                switch result {
                case .success:
                    AddCreneauBenevole(flexible: 1, idCreneau: self.creneau!.idCreneau, idUser: userId) { result in
                        switch result {
                        case .success:
                            print("Inscription du bénévole réussie.")
                            self.isInscrit = "flexible"
                        case .failure(let error):
                            print("Erreur lors de l'inscription du bénévole:", error)
                        }
                    }
                case .failure(let error):
                    print("Erreur lors de l'ajout du nombre d'inscrits:", error)
                }
            }
        } else {
            self.creneau!.nb_inscrit += 1
            AddNbInscrit(idCreneau: self.creneau!.idCreneau) { result in
                switch result {
                case .success:
                    AddCreneauBenevole(flexible: 0, idCreneau: self.creneau!.idCreneau, idUser: userId) { result in
                        switch result {
                        case .success:
                            print("Inscription du bénévole réussie.")
                            self.isInscrit = "oui"
                        case .failure(let error):
                            print("Erreur lors de l'inscription du bénévole:", error)
                        }
                    }
                case .failure(let error):
                    print("Erreur lors de l'ajout du nombre d'inscrits:", error)
                }
            }
        }
    }
    
    func desinscriptionBenevole(flexible: Bool) {
        
        let userId = AuthenticationManager.shared.retrieveUserIdFromKeychain()
        
        guard let userId = userId else {
            print("Erreur: Impossible de récupérer l'ID de l'utilisateur.")
            return
        }
        
        if flexible {
            creneau!.nb_inscrit_flexible -= 1
            RemoveNbInscritFlexible(idCreneau: self.creneau!.idCreneau) { result in
                switch result {
                case .success:
                    RemoveCreneauBenevole(idCreneau: self.creneau!.idCreneau, idUser: userId) { result in
                        switch result {
                        case .success:
                            print("Désinscription du bénévole réussie.")
                            self.isInscrit = "non"
                        case .failure(let error):
                            print("Erreur lors de la désinscription du bénévole:", error)
                        }
                    }
                case .failure(let error):
                    print("Erreur lors de la suppression du nombre d'inscrits:", error)
                }
            }
        } else {
            creneau!.nb_inscrit -= 1
            RemoveNbInscrit(idCreneau: self.creneau!.idCreneau) { result in
                switch result {
                case .success:
                    RemoveCreneauBenevole(idCreneau: self.creneau!.idCreneau, idUser: userId) { result in
                        switch result {
                        case .success:
                            print("Désinscription du bénévole réussie.")
                            self.isInscrit = "non"
                        case .failure(let error):
                            print("Erreur lors de la désinscription du bénévole:", error)
                        }
                    }
                case .failure(let error):
                    print("Erreur lors de la suppression du nombre d'inscrits:", error)
                }
            }
        }
    }
    
    
    func CircleColor(percentage:CGFloat) -> LinearGradient{
        guard let creneau = creneau else
        {
            print("Erreur : Le créneau n'est pas défini.")
            return LinearGradient(gradient: Gradient(colors: [Color.gray, Color.gray]), startPoint: .leading, endPoint: .trailing)
        }
            if percentage == 0{
                print("2")
                return LinearGradient(gradient: Gradient(colors: [Color.gray, Color.gray]), startPoint: .leading, endPoint: .trailing)
            }
            if percentage < 0.33{
                print("3")
                return LinearGradient(gradient: Gradient(colors: [Color.red, Color.red]), startPoint: .leading, endPoint: .trailing)
            }
            else if percentage >= 0.33 && percentage < 0.66{
                print("4")
                return LinearGradient(gradient: Gradient(colors: [Color.yellow, Color.yellow]), startPoint: .leading, endPoint: .trailing)
            }
            else {
                print("5")
                return LinearGradient(gradient: Gradient(colors: [Color.green, Color.green]), startPoint: .leading, endPoint: .trailing)
            }
        }
}

