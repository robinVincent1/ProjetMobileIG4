//
//  CreneauViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 17/03/2024.
//

import Foundation


func AddNbInscrit(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    print(idCreneau)
    let url = URL(string: "\(urlAPI)/creneau/addnbinscrit/\(idCreneau)")!
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        completion(.success(()))
    }.resume()
}

func AddCreneauBenevole(idCreneau: Int, idUser: String, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    
    let url = URL(string: "\(urlAPI)/creneau_benevole/")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    let requestData: [String: Any] = [
        "idCreneau": idCreneau,
        "idUser": idUser
    ]
    
    do {
        request.httpBody = try JSONSerialization.data(withJSONObject: requestData)
    } catch {
        completion(.failure(error))
        return
    }
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        completion(.success(()))
    }.resume()
}


func RemoveNbInscrit(idCreneau: Int, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    
    let url = URL(string: "\(urlAPI)/creneau/subnbinscrit/\(idCreneau)")!
    var request = URLRequest(url: url)
    request.httpMethod = "PUT"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        completion(.success(()))
    }.resume()
}

func RemoveCreneauBenevole(idCreneau: Int, idUser: String, completion: @escaping (Result<Void, Error>) -> Void) {
    let token = AuthenticationManager.shared.retrieveTokenFromKeychain()
    
    guard let token = token else {
        return
    }
    
    let url = URL(string: "\(urlAPI)/creneau_benevole")!
    var request = URLRequest(url: url)
    request.httpMethod = "DELETE"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    
    let requestData: [String: Any] = [
        "idCreneau": idCreneau,
        "idUser": idUser
    ]
    
    do {
        request.httpBody = try JSONSerialization.data(withJSONObject: requestData)
    } catch {
        completion(.failure(error))
        return
    }
    
    URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            completion(.failure(error))
            return
        }
        
        // Traitez ici la réponse de la requête si nécessaire
        
        completion(.success(()))
    }.resume()
}

