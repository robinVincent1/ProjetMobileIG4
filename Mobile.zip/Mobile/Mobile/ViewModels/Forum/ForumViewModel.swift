//
//  ForumViewModel.swift
//  Mobile
//
//  Created by Robin Vincent on 20/03/2024.
//

import Foundation

class ForumViewModel: ObservableObject {
    @Published var questions: [Question] = []
    @Published var errorMessage = ""
    @Published var isLoading = true
    @Published var user: User? = nil
    @Published var presented : Bool = false

    func fetchQuestion(){
        let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
        if let idUser = idUser {
            getUserFromAPI { result in
                switch result {
                case .success(let user):
                    self.isLoading = false
                    DispatchQueue.main.async {
                        self.user = user
                    }
                case .failure(let error):
                    print("Erreur lors de la récupération de l'utilisateur : \(error)")
                    // Traitez l'erreur ici
                }
            }
        }
        getQuestionsFromAPI { result in
            DispatchQueue.main.async {
                self.isLoading = false
                switch result {
                case .success(let questionList):
                    self.questions = questionList
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    func sendReponse(createur: String, responseText: String, questionId: Int) {
        postResponseToAPI(createur: createur, responseText: responseText, questionId: questionId){ result in
            DispatchQueue.main.async {
                switch result {
                case .success():
                    self.fetchQuestion()
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    
    func sendQuestion(createur: String, question: String, objet: String) {
        postQuestionToAPI(createur: createur, question: question, objet: objet){ result in
            DispatchQueue.main.async {
                switch result {
                case .success():
                    self.fetchQuestion()
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    func deleteReponse(reponseId: Int) {
         deleteReponseToAPI(reponseId: reponseId) { result in
            DispatchQueue.main.async {
                switch result {
                case .success():
                    self.fetchQuestion()
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
    func deleteQuestion(questionId: Int) {
         deleteQuestionToAPI(questionId: questionId) { result in
            DispatchQueue.main.async {
                switch result {
                case .success():
                    self.fetchQuestion()
                case .failure(let error):
                    self.errorMessage = "Erreur: \(error.localizedDescription)"
                }
            }
        }
    }
    
}

