//
//  ProfilModel.swift
//  Mobile
//
//  Created by Robin Vincent on 14/03/2024.
//

import Foundation


class ProfileViewModel: ObservableObject {
    @Published var user: User?
    @Published var isEditing = false
    
    @Published var pseudo : String = ""
    @Published var email : String = ""
    @Published var telephone: String = ""
    @Published var association : String = ""
    @Published var postalAdress: String = ""
    
    // Fonction pour récupérer l'utilisateur depuis l'API
    func getUser() {
        // Appel de la fonction pour récupérer l'utilisateur depuis l'API
        getUserFromAPI { result in
            switch result {
            case .success(let user):
                DispatchQueue.main.async {
                    self.user = user
                    self.pseudo = user.pseudo ?? ""
                    self.email = user.email
                    self.association = user.association ?? ""
                    self.telephone = user.telephone ?? ""
                }
            case .failure(let error):
                print("Erreur lors de la récupération de l'utilisateur : \(error)")
                // Traitez l'erreur ici
            }
        }
    }
    
    //fonction pour modifier le profil de l'utilisateur
    func updateUser(email: String, telephone: String, association: String, pseudo: String, postalAdress: String) {
        guard let token = AuthenticationManager.shared.retrieveTokenFromKeychain(),
              let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain() else {
            return
        }
        
        let url = URL(string: "\(urlAPI)/user/ModifProfil")!
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        
        let parameters: [String: Any] = [
            "idUser": idUser,
            "email": email,
            "telephone": telephone,
            "association": association,
            "pseudo": pseudo,
            "postalAdress": postalAdress
        ]
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: parameters)
            request.httpBody = jsonData
            
            URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
                guard let data = data, error == nil else {
                    if let error = error {
                        print("Error: \(error)")
                    }
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                    print("Error: Invalid status code")
                    return
                }
                
                do {
                    let updatedUser = try JSONDecoder().decode(User.self, from: data)
                    DispatchQueue.main.async {
                        self?.user = updatedUser
                    }
                } catch {
                    print("Error decoding updated user: \(error)")
                }
            }.resume()
        } catch {
            print("Error serializing JSON: \(error)")
        }
    }
}
