import SwiftUI

struct ProfileView: View {
    @StateObject var viewModel = ProfileViewModel()

    var body: some View {
        VStack {
            if let user = viewModel.user {
                ProfileContentView(user: user, isEditing: viewModel.isEditing, viewModel: viewModel)
            } else {
                Text("Chargement en cours...")
            }
        }
        .navigationBarTitle("Profil")
        .navigationBarItems(trailing: Button(action: {
            viewModel.isEditing.toggle()
            if viewModel.isEditing {
                viewModel.getUser()
            }
        }) {
            Text(viewModel.isEditing ? "Valider" : "Modifier")
        })
        .onAppear {
            viewModel.getUser()
        }
    }
}


struct ProfileContentView: View {
    var user: User
    var isEditing: Bool
    @ObservedObject var viewModel: ProfileViewModel


    var body: some View {
        VStack {

            AvatarView(user: user)
                .bold()
            Spacer()
            
            HStack {
                VStack {
                    Text("\(user.firstName) \(user.lastName)")
                        .font(.title2)
                        .bold()
                    Text("Nom")
                        .italic()
                }
                VStack {
                    Text("\(user.nbEdition)")
                        .font(.title2)
                        .bold()
                    Text("Edition(s)")
                        .italic()
                }
                VStack {
                    Text("\(user.role)")
                        .font(.title2)
                        .bold()
                    Text("Role")
                        .italic()
                }
            }
            
            Spacer()

            EditableField(title: "Pseudo", placeholder: "Pseudo", text: $viewModel.pseudo)
            EditableField(title: "E-mail", placeholder: "E-mail", text: $viewModel.email)
            EditableField(title: "Adresse", placeholder: "Adresse", text: $viewModel.postalAdress)
            EditableField(title: "Téléphone", placeholder: "Téléphone", text: $viewModel.telephone)
            EditableField(title: "Association", placeholder: "Association", text: $viewModel.association)
            
            Button(action: {
                // Appel de la fonction pour envoyer les modifications
                viewModel.updateUser(email: viewModel.email, telephone: viewModel.telephone, association: viewModel.association, pseudo: viewModel.pseudo, postalAdress: viewModel.postalAdress)
            }) {
                Text("Modifier")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(8)
                    .shadow(color: .gray, radius: 3, x: 0, y: 2)
            }


            Spacer()
        }
        .padding()
    }
}



struct AvatarView: View {
    var user: User

    var body: some View {
        ZStack {
            Circle()
                .fill(Color.blue)
                .frame(width: 100, height: 100)
            Text(user.firstName.prefix(1))
                .font(.title)
                .foregroundColor(.white)
        }
        .padding(.bottom, 20)
    }
}

struct EditableField: View {
    var title: String
    var placeholder: String
    @Binding var text: String

    var body: some View {
        HStack {
            Text(title)
                .font(.headline)
            TextField(placeholder, text: $text)
                .textFieldStyle(RoundedBorderTextFieldStyle())
        }
        .padding(.vertical, 5)
    }
}

struct ProfilsView_Preview: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
