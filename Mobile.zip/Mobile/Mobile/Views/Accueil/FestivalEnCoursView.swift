//
//  FestivalEnCoursView.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import SwiftUI

import SwiftUI

struct FestivalEnCoursView: View {
    @StateObject var viewModel = FestivalEnCoursViewModel()

    var body: some View {
        VStack {
            if viewModel.isLoading {
               SkeletonCellView()
                    .padding()
            } else if let festival = viewModel.festival {
                VStack(alignment: .center, spacing: 10) {
                    NavigationLink(destination: ListeJeuView()) {
                        Text(festival.nom)
                            .font(.title2)
                            .bold()
                            .foregroundColor(Color("DarkBlue"))
                    }
                    Text(" \(festival.date)")
                        .font(.body)
                        .foregroundColor(.black)
                        .italic()
                }
                
                if viewModel.isInscrit {
                    Image(systemName: "person.crop.circle.badge.checkmark")
                        .foregroundColor(Color("Vert"))
                        .padding()
                        .imageScale(.large)
                } else {
                    Button(action: {
                        viewModel.inscrireAuFestival()
                    }) {
                        Text("S'inscrire")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 150) // Largeur fixe
                            .background(Color("DarkBlue"))
                            .cornerRadius(8)
                            .shadow(color: .gray, radius: 3, x: 0, y: 2)
                    }
                }
            }
        }
        .onAppear {
            viewModel.fetchFestivalData()
        }
    }
}

struct FestivalEnCoursView_Previews: PreviewProvider {
    static var previews: some View {
        FestivalEnCoursView()
    }
}

