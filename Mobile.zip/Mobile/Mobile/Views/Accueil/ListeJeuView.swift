//
//  ContentView.swift
//  SwiftUI_TableView_Sample
//
//  Created by YOUNGSIC KIM on 2019-10-13.
//  Copyright © 2019 YOUNGSIC KIM. All rights reserved.
//

import SwiftUI

struct ListeJeuView: View {
    @StateObject var viewModel = ListeJeuViewModel()
    @State var dropDown = "all"
    @State var showdropdown = true
    
    var body: some View {
        VStack {
            if viewModel.isLoading {
                ProgressView("Chargement en cours...")
            } else if !viewModel.csv.isEmpty {
                if showdropdown {
                    // Menu déroulant pour sélectionner l'espace
                    Menu {
                        ForEach(viewModel.listeEspace, id: \.self) { espace in
                            Button(action: {
                                dropDown = espace.planZone
                                // Mettre à jour les jeux en fonction de l'espace sélectionné
                                viewModel.fetchCsv(zone: espace.planZone)
                            }, label: {
                                Text(espace.planZone)
                            })
                        }
                    } label: {
                        Text("\(dropDown)")
                    }
                    .padding()
                }

                
                NavigationView {
                    // Liste des jeux
                    List(viewModel.csv) { jeu in
                        JeuCell(jeu: jeu)
                    }
                }
            } else {
                Text(viewModel.errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .onAppear {
            // Chargement des espaces et des jeux au chargement de la vue
            viewModel.fetchEspace()
            viewModel.fetchCsv(zone: dropDown)
        }
    }
}




struct ListeJeuView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ListeJeuView()
            ListeJeuView()
                .environment(\.colorScheme, .dark)
            ListeJeuView()
                .environment(\.sizeCategory, .extraExtraExtraLarge)
        }
    }
}

struct JeuCell: View {
    let jeu: Csv
    var body: some View {
        NavigationLink(destination: JeuCell(jeu: jeu)) {
            AsyncImage(url: URL(string: jeu.logo)){
                image in image.image?.resizable()
            }
                .cornerRadius(8)
                .frame(width: 50, height: 50)
                
            VStack (alignment: .leading){
                Text(jeu.nameGame)
                Text("Number: \(jeu.nbPlayers)")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }.navigationBarTitle("Jeu")
    }
}
