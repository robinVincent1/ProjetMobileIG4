//
//  InfosView.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import SwiftUI

import SwiftUI

struct InfosView: View {
    @StateObject var viewModel = InfosViewModel()

    var body: some View {
        VStack {
            if viewModel.isLoading {
                ProgressView("Chargement en cours...")
            } else if !viewModel.infos.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(viewModel.infos, id: \.idInfos) { infoItem in
                            InfoCard(info: infoItem)
                        }
                    }
                    .padding()
                }
            } else {
                Text(viewModel.errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .onAppear {
            viewModel.fetchInfos()
        }
    }
}


struct InfoCard: View {
    let info: Infos
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(info.titre)
                .font(.title2)
                .foregroundColor(.white)
                .bold()
            Text(info.description)
                .foregroundColor(.white)
        }

        .frame(width: 200, height: 120)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(10)
    }
}

struct InfosView_Previews: PreviewProvider {
    static var previews: some View {
        InfosView()
    }
}


