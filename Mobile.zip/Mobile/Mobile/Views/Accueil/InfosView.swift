//
//  InfosView.swift
//  Mobile
//
//  Created by Robin Vincent on 15/03/2024.
//

import SwiftUI

import SwiftUI

struct InfosView: View {
    @StateObject var viewModel = InfosViewModel()

    var body: some View {
        VStack {
            if viewModel.isLoading {
                SkeletonCellView()
                    .padding()
            }
            else if !viewModel.infos.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(viewModel.infos, id: \.idInfos) { infoItem in
                            
                            CourseView(title: infoItem.titre, image: "", description: infoItem.description,color: Color("Vert"), shadowColor: Color.gray)
                        }
                    }
                    .padding()
                }
            }
        }
        .onAppear {
            viewModel.fetchInfos()
        }
    }
}


struct CourseView: View {
    
    var title = "Build an app with SwiftUI"
    var image = "Illustration1"
     var description = ""
     var color = Color.gray
    var shadowColor = Color("backgroundShadow3")

    var body: some View {
       return VStack(alignment: .leading) {
          Text(title)
             .font(.title)
             .fontWeight(.bold)
             .foregroundColor(.white)
             .padding(30)
             .lineLimit(4)

           Text(description)
              .font(.title3)
              .foregroundColor(.white)
              .padding(30)
              .lineLimit(4)
       }
       .background(color)
       .cornerRadius(30)
       .frame(width: 246, height: 360)
       .shadow(color: shadowColor, radius: 20, x: 0, y: 20)
    }
 }

 struct Course: Identifiable {
    var id = UUID()
    var title: String
    var image: String
    var color: Color
    var shadowColor: Color
     var description: String
 }

struct InfosView_Previews: PreviewProvider {
    static var previews: some View {
        InfosView()
    }
}


