import SwiftUI

import SwiftUI

struct NewsView: View {
    @StateObject var viewModel = NewsViewModel()

    var body: some View {
        VStack {
            if viewModel.isLoading {
                ProgressView("Chargement en cours...")
            } else if !viewModel.news.isEmpty {
                ScrollView(.horizontal, showsIndicators: true) {
                    HStack(spacing: 20) {
                        ForEach(viewModel.news, id: \.idNews) { newsItem in
                            VStack(alignment: .leading) {
                                Text(newsItem.titre)
                                    .font(.headline)
                                    .foregroundColor(.blue)
                                Text(newsItem.description)
                                    .font(.body)
                                    .foregroundColor(.black)
                            }
                            .padding()
                        }
                    }
                    .padding(.horizontal)
                }
                .frame(height: 180)
            } else {
                Text(viewModel.errorMessage)
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .onAppear {
            viewModel.fetchNews()
        }
    }
}


struct NewsView_Previews: PreviewProvider {
    static var previews: some View {
        NewsView()
    }
}
