import SwiftUI

struct AccueilView: View {
    var body: some View {
        NavigationView { // Ajout de NavigationView
            ScrollView {
                VStack {
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    HStack {
                        Text("                    ")
                    }
                    .background(
                        Image("Accueil")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 280, height: 280) // Réduire la taille du logo
                    )
                    
                    InfosView()
                    
                    FestivalEnCoursView()
                        .padding()
                        .background(Color.white)
                        .cornerRadius(15)
                        .shadow(radius: 5)
                    

                    Spacer()
                    Spacer()
                    
                }
                .navigationBarTitle("") // Suppression du titre de la navigation bar
                .navigationBarHidden(true) // Masquage de la navigation bar
            }
        }
    }
}

struct AccueilView_Previews: PreviewProvider {
    static var previews: some View {
        AccueilView()
    }
}
