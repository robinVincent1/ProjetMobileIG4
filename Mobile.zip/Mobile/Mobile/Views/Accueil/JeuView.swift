import SwiftUI

struct JeuView: View {
    let jeu: Csv
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text(jeu.nameGame)
                    .font(.title)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                    .padding(.top, 20)
                
                AsyncImage(url: URL(string: jeu.logo)) { image in
                    image.image?
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .cornerRadius(20)
                }
                .frame(maxWidth: .infinity, maxHeight: 300)
                .padding(.horizontal, 20)
                
                VStack(alignment: .leading, spacing: 10) {
                    InfoRow(title: "Auteur", value: jeu.author ?? "")
                    InfoRow(title: "Nombre de joueurs", value: jeu.nbPlayers ?? "")
                    InfoRow(title: "Âge minimum", value: jeu.minAge ?? "")
                    InfoRow(title: "Description", value: jeu.description ?? "")
                }
                .padding(.horizontal, 20)
                
                Spacer()
            }
            .padding(.bottom, 20)
        }
    }
}

struct InfoRow: View {
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title)
                .foregroundColor(.blue)
                .font(.headline)
            Spacer()
            Text(value)
                .font(.headline)
        }
    }
}

