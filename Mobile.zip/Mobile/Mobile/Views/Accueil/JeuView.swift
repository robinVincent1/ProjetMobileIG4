//
//  DetailView.swift
//  SwiftUI_TableView_Sample
//
//  Created by YOUNGSIC KIM on 2019-10-13.
//  Copyright © 2019 YOUNGSIC KIM. All rights reserved.
//

import SwiftUI

struct JeuView: View {
    let jeu : Csv
    @State private var zoomed = false
    var body: some View {
        ZStack (alignment:.topLeading){
            AsyncImage(url: URL(string: jeu.logo))
            }
            if !zoomed {
                Text("Touch The Image")
                    .font(.title)
                    .padding(.all)
                    .transition(.move(edge: .leading))
            }
        }
    }

