import SwiftUI

struct PlanningView: View {
    @State private var planning = "Planning personnel"

    var body: some View {
        NavigationView {
            VStack {
                Text(planning)
                    .foregroundColor(Color("DarkBlue"))
                    .font(.title)
                    .bold()
                // Afficher la vue correspondant au planning sélectionné
                if planning == "Planning personnel" {
                    PlanningPersoView()
                } else if planning == "Planning poste" {
                    PlanningGeneralView()
                } else {
                    PlanningAnimationView()
                }
            }
            .toolbar {
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu("Plannings") {
                        Button("Personnel") {
                            planning = "Planning personnel"
                        }
                        Button("Général") {
                            planning = "Planning général"
                        }
                        Button("Jeux") {
                            planning = "Planning jeux"
                        }
                    }
                    .foregroundColor(Color.red)
                    .bold()
                   
                }
            }
        }
    }
}

struct PlanningView_Previews: PreviewProvider {
    static var previews: some View {
        PlanningView()
    }
}
