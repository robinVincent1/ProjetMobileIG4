//
//  SwiftUIView.swift
//  Mobile
//
//  Created by Robin Vincent on 13/03/2024.
//

import SwiftUI
import UIKit

struct PlanningAnimationView: UIViewControllerRepresentable{
    func makeUIViewController(context: Context) -> PlanningAnimationController{
        return PlanningAnimationController()
    }
    
    func updateUIViewController(_ uiViewController: PlanningAnimationController, context: Context) {
        //code
    }
    
    typealias UIViewControllerType = PlanningAnimationController
}

