//
//  PosteView.swift
//  Mobile
//
//  Created by Robin Vincent on 17/03/2024.
//

import SwiftUI

struct PosteView: View {
    
    var id: Int
    
    @State private var creneaux: [Creneau] = []
    @State private var isModalPresented = false
    @State private var selectedCreneau: Creneau? = nil
    @State private var selectedCreneauId: Int? = nil

    var body: some View {
        NavigationView {
            List(creneaux, id: \.idCreneau) { creneau in
                NavigationLink(destination: CreneauView(id: creneau.idCreneau)) {
                    Text(creneau.titre)
                }
            }
        }
        .onAppear() {
            fetchCreneaux()
        }
    }
    
    private func fetchCreneaux() {
        guard let creneau = getCreneauFromAPI(url: "\(urlAPI)/creneau/getbyid/\(id)") else {
            return
        }
        
        // Convertir les valeurs d'heure_debut et heure_fin en chaînes de caractères
        let heureDebutString = String(creneau.heure_debut)
        let heureFinString = String(creneau.heure_fin)
        
        print(creneau.date)
        print(heureDebutString)
        print(heureFinString)
        
        // Utiliser les chaînes de caractères converties dans l'URL
        getCreneauxByHoraire(url: "\(urlAPI)/creneau/getbydateandhoraire/\(creneau.date)/\(heureDebutString)/\(heureFinString)") { fetchedCreneaux in
            if let fetchedCreneaux = fetchedCreneaux {
                self.creneaux = fetchedCreneaux
            } else {
                self.creneaux = [] // Ou toute autre logique de gestion d'erreur
            }
        }
    }
} 

 


#Preview {
    PosteView(id: 1)
} 
