import SwiftUI

struct PosteView: View {
    @StateObject private var viewModel = PosteViewModel()
    @Environment(\.presentationMode) var presentationMode // Ajout de l'environnement de présentation

    var id: Int

    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Image(systemName: "list.bullet.clipboard")
                    Text("Liste des différents postes")
                }
                .font(.title3)
                .bold()
                .padding()
                VStack{
                    HStack {
                        Image(systemName:"calendar")
                        Text("\(viewModel.annee)/\(viewModel.mois)/\(viewModel.jour)")
                    }
                    HStack{
                        Image(systemName:"clock")
                        Text("\(viewModel.heuredebut)h-\(viewModel.heurefin)h")
                    }
                }
                List(viewModel.creneaux, id: \.idCreneau) { creneau in
                    NavigationLink(destination: CreneauView(id: creneau.idCreneau, postViewModel: viewModel)) {
                        Text(creneau.titre)
                    }
                }

                .navigationBarItems(leading: Button(action: {
                    presentationMode.wrappedValue.dismiss() // Dismiss la vue
                }) {
                    Image(systemName: "arrow.backward") // Ajouter une icône de retour
                    Text("Back") // Texte pour le bouton
                })
            }
        }
        .onAppear() {
            viewModel.fetchCreneaux(id: id)
        }
    }
}


struct PosteView_Previews: PreviewProvider {
    static var previews: some View {
        PosteView(id: 1)
    }
}
