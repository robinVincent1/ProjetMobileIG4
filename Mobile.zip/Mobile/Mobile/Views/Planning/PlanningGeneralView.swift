//
//  SwiftUIView.swift
//  Mobile
//
//  Created by Robin Vincent on 13/03/2024.
//

import SwiftUI
import UIKit

struct PlanningGeneralView: UIViewControllerRepresentable{
    func makeUIViewController(context: Context) -> PlanningGeneralController{
        return PlanningGeneralController()
    }
    
    func updateUIViewController(_ uiViewController: PlanningGeneralController, context: Context) {
        //code
    }
    
    typealias UIViewControllerType = PlanningGeneralController
}

