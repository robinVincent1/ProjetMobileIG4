import SwiftUI

struct CreneauView: View {
    @Environment(\.presentationMode) var presentationMode
    @State public var id: Int
    
    @State public var creneau: Creneau? = nil
    
    @State var isInscrit : Bool? = nil
    
    var progress: CGFloat{
        if let creneau = creneau {
            return CGFloat(creneau.nb_inscrit)/CGFloat(creneau.nb_max)
        }
        return 0
    }
    
    var body: some View {
        NavigationView {
            VStack {
                if let creneau = creneau {
                    // Affichage des données du créneau si elles sont disponibles
                    
                    Text("Titre: \(creneau.titre)")
                        .padding()
                        .font(.title)
                    
                    CircularProgressView(count: creneau.nb_inscrit, total: creneau.nb_max, progress: progress)
                        .padding()
                    
                    if let isInscrit = isInscrit {
                        if !isInscrit {
                            Button(action:inscriptionBenevole){
                                Text("S'inscrire")
                            }
                        }
                        else {
                            Button(action: desinscriptionBenevole){
                                Text("Se désinscrire")
                            }
                        }
                    }

                    // Ajoutez d'autres Text pour afficher d'autres propriétés du creneau si nécessaire
                } else {
                    // Affichage d'un indicateur de chargement pendant que les données sont récupérées
                    ProgressView()
                }
            }
            .navigationBarTitle("Titre", displayMode: .inline)
            /*
            .navigationBarItems(leading: Button(action: {
                self.presentationMode.wrappedValue.dismiss()
            }) {
                Image(systemName: "chevron.left")
                Text("Retour")
            })*/
            .onAppear() {
                creneau = getCreneauFromAPI(url: "\(urlAPI)/creneau/getbyid/\(id)")
                let idUser = AuthenticationManager.shared.retrieveUserIdFromKeychain()
                if let idUser = idUser {
                    if let id  = creneau?.idCreneau {
                        getIsInscrit(url: "\(urlAPI)/creneau_benevole/isInscrit/\(idUser)/\(id)") { isInscrit in
                            // Utilisez la valeur de 'isInscrit' ici
                            if isInscrit {
                                // L'utilisateur est inscrit au créneau
                                print("L'utilisateur est inscrit au créneau.")
                                self.isInscrit = true
                            } else {
                                // L'utilisateur n'est pas inscrit au créneau
                                print("L'utilisateur n'est pas inscrit au créneau.")
                                self.isInscrit = false
                            }
                        }

                    }
                }
            }
        }
    }
    func inscriptionBenevole() {
        guard creneau != nil else {
            print("Erreur: Le créneau n'est pas défini.")
            return
        }
        
        let userId = AuthenticationManager.shared.retrieveUserIdFromKeychain()
        
        guard let userId = userId else {
            print("Erreur: Impossible de récupérer l'ID de l'utilisateur.")
            return
        }
        
        // Augmenter le nombre d'inscrits pour ce créneau
        self.creneau?.nb_inscrit += 1
        
        if let id = self.creneau?.idCreneau {
            // Appeler AddNbInscrit avec l'ID du créneau correct
            AddNbInscrit(idCreneau: id) { result in
                switch result {
                    case .success:
                        // Ajouter le bénévole à ce créneau
                        AddCreneauBenevole(idCreneau: id, idUser: userId) { result in
                            switch result {
                                case .success:
                                    print("Inscription du bénévole réussie.")
                                isInscrit = true
                                case .failure(let error):
                                    print("Erreur lors de l'inscription du bénévole:", error)
                            }
                        }
                    case .failure(let error):
                        print("Erreur lors de l'ajout du nombre d'inscrits:", error)
                }
            }
        }
    }

    
    func desinscriptionBenevole() {
        guard let creneau = self.creneau else {
            print("Erreur: Le créneau n'est pas défini.")
            return
        }
        
        let userId = AuthenticationManager.shared.retrieveUserIdFromKeychain()
        
        guard let userId = userId else {
            print("Erreur: Impossible de récupérer l'ID de l'utilisateur.")
            return
        }
        
        // Diminuer le nombre d'inscrits pour ce créneau
        self.creneau?.nb_inscrit -= 1
        
        if let id = self.creneau?.idCreneau {
            // Appeler RemoveNbInscrit avec l'ID du créneau correct
            RemoveNbInscrit(idCreneau: id) { result in
                switch result {
                    case .success:
                        // Retirer le bénévole de ce créneau
                        RemoveCreneauBenevole(idCreneau: id, idUser: userId) { result in
                            switch result {
                                case .success:
                                    print("Désinscription du bénévole réussie.")
                                isInscrit = false
                                case .failure(let error):
                                    print("Erreur lors de la désinscription du bénévole:", error)
                            }
                        }
                    case .failure(let error):
                        print("Erreur lors de la suppression du nombre d'inscrits:", error)
                }
            }
        }
    }

    
}
                           


// Code pour l'aperçu de la vue
struct CreneauView_Previews: PreviewProvider {
    static var previews: some View {
        CreneauView(id: 1)
    }
}
