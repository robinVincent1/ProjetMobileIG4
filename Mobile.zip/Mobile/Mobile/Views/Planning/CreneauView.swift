import SwiftUI

struct CreneauView: View {
    @Environment(\.presentationMode) var presentationMode
    @StateObject var viewModel = CreneauViewModel()
    var id: Int
    var postViewModel : PosteViewModel
    
    var progress: CGFloat {
        guard let creneau = viewModel.creneau else { return 0 }
        let progress = CGFloat(creneau.nb_inscrit + creneau.nb_inscrit_flexible) / CGFloat(creneau.nb_max)
        return progress
    }
    
    var body: some View {
        NavigationView {
            VStack {
                if let creneau = viewModel.creneau {
                    // Affichage des données du créneau si elles sont disponibles
                    // Utilisez viewModel.creneau au lieu de creneau
                    
                    Text("\(creneau.titre)")
                        .padding()
                        .font(.title)
                        .bold()
                    
                    CircularProgressView(count: creneau.nb_inscrit + creneau.nb_inscrit_flexible, total: creneau.nb_max, progress: progress, fill: viewModel.CircleColor(percentage:progress))
                        .padding(EdgeInsets(top: 20, leading: 50, bottom: 12, trailing: 50))
                    
                    Spacer()
                    
                    Text("Dont \(creneau.nb_inscrit_flexible) flexible(s)")
                        .bold()
                        .font(.title3)
                    
                    Spacer()
                    
                    if let isInscrit = viewModel.isInscrit {
                        if !postViewModel.dejaInscrit {
                            if isInscrit == "non" {
                                Button(action: {
                                    viewModel.inscriptionBenevole(flexible: false)
                                    postViewModel.dejaInscrit = true
                                }) {
                                    HStack {
                                        Text("S'inscrire")
                                        Image(systemName: "person.fill.checkmark")
                                    }
                                    .padding()
                                }
                                .foregroundColor(.blue)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.blue, lineWidth: 2)
                                )
                                
                                Button(action: {
                                    viewModel.inscriptionBenevole(flexible: true)
                                    postViewModel.dejaInscrit = true
                                }) {
                                    HStack {
                                        Text("S'inscrire (Flexible)")
                                        Image(systemName: "person.fill.questionmark")
                                    }
                                    .padding()
                                }
                                .foregroundColor(.blue)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.blue, lineWidth: 2)
                                )
                            } else if isInscrit == "oui" {
                                Button(action: {
                                    viewModel.desinscriptionBenevole(flexible: false)
                                    postViewModel.dejaInscrit = false
                                }) {
                                    HStack {
                                        Text("Se désinscrire")
                                        Image(systemName: "person.fill.xmark")
                                    }
                                    .padding()
                                }
                                .foregroundColor(.blue)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.blue, lineWidth: 2)
                                )
                            }  else if isInscrit == "flexible" {
                                Button(action: {
                                    viewModel.desinscriptionBenevole(flexible: true)
                                    postViewModel.dejaInscrit = false
                                }) {
                                    HStack {
                                        Text("Se désinscrire")
                                        Image(systemName: "person.fill.xmark")
                                    }
                                    .padding()
                                }
                                .foregroundColor(.blue)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.blue, lineWidth: 2)
                                )
                            }
                        } else if postViewModel.dejaInscrit && (viewModel.isInscrit == "oui" || viewModel.isInscrit == "flexible") {
                            if viewModel.isInscrit == "oui" {
                                
                                Button(action: {
                                    viewModel.desinscriptionBenevole(flexible: false)
                                    postViewModel.dejaInscrit = false
                                }) {
                                    HStack {
                                        Text("Se désinscrire")
                                        Image(systemName: "person.fill.xmark")
                                    }
                                    .padding()
                                }
                                .foregroundColor(.blue)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.blue, lineWidth: 2)
                                )
                            } else {
                                Button(action: {
                                    viewModel.desinscriptionBenevole(flexible: true)
                                    postViewModel.dejaInscrit = false
                                }) {
                                    HStack {
                                        Text("Se désinscrire")
                                        Image(systemName: "person.fill.xmark")
                                    }
                                    .padding()
                                }
                                .foregroundColor(.blue)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 8)
                                        .stroke(Color.blue, lineWidth: 2)
                                )
                            }
                        }
                        Spacer()
                        
                        // Ajoutez d'autres Text pour afficher d'autres propriétés du creneau si nécessaire
                    } else {
                        // Affichage d'un indicateur de chargement pendant que les données sont récupérées
                        ProgressView()
                    }
                }
                
            }
            .onAppear {
                viewModel.fetchCreneau(id: id)
            }
        }
        

        
    }

}


// Style pour les boutons remplis
struct FilledButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding()
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(8)
    }
}


