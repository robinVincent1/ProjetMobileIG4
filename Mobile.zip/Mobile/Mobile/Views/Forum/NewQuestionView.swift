//
//  NewQuestionView.swift
//  Mobile
//
//  Created by Robin Vincent on 20/03/2024.
//

import SwiftUI


struct NewQuestionView: View {
    @State private var question = ""
    @State private var objet = ""
    var viewModel : ForumViewModel
    @Environment(\.presentationMode) var presentationMode
    
    
    var body: some View {
        VStack {
            
            Spacer()
            
                Text("Posez votre question")
                    .font(.title)
                    .padding()
                    .bold()
                    .foregroundColor(Color("DarkBlue"))
            
            
            HStack{
                Image(systemName: "doc")
            TextField("Objet", text: $objet)
                .cornerRadius(8)
                .padding(.horizontal)
                .textFieldStyle(.roundedBorder)
            }
            .padding()
            
            HStack{
                Image(systemName: "questionmark.bubble")
            TextField("Question", text: $question)
                .cornerRadius(8)
                .textFieldStyle(.roundedBorder)
            }
            .padding()
            

            
            Button(action: {
                // Action pour soumettre la question
                viewModel.sendQuestion(createur: viewModel.user?.firstName ?? "", question: question, objet: objet)
                presentationMode.wrappedValue.dismiss()
            }) {
                Text("Envoyer")
                Image(systemName: "paperplane")
            }
            .padding()
            .foregroundColor(.white)
            .background(Color("Vert"))
            .cornerRadius(8)
            
            Spacer()
        }
    }
}
