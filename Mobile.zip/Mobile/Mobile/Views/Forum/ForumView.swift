import SwiftUI
import Foundation

struct ForumView: View {
    @StateObject var viewModel = ForumViewModel()
    @State private var isPresentingNewQuestion = false
    @State var isDeleted : Bool = false

    var body: some View {
        NavigationView {
            VStack {
                if viewModel.isLoading {
                    ProgressView("Chargement en cours...")
                } else if !viewModel.questions.isEmpty {
                    
                    HStack {
                    
                        if isDeleted {
                            Button(action: {
                                isDeleted = false
                            }) {
                                Image(systemName: "trash.slash")
                                    .foregroundColor(Color("BleuClair"))
                                    
                            }
                            .padding()
                        } else {
                            Button(action: {
                                isDeleted = true
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(Color("BleuClair"))
                            }
                            .padding()
                        }
                        
                        Spacer()
                        
                        Text("Forum")
                            .font(.title)
                            .padding()
                            .bold()
                            .foregroundColor(Color("DarkBlue"))

                        
                        Spacer()
                        
                        Button(action: {
                            isPresentingNewQuestion.toggle()
                        }) {
                            Image(systemName: "plus.app")
                                .imageScale(.large)
                                .foregroundColor(Color("BleuClair"))
                        }
                        .sheet(isPresented: $isPresentingNewQuestion) {
                            NewQuestionView(viewModel: viewModel)
                        }
                        .padding()
                        
                    }
                    
                    NewsView()
                    
                    List(viewModel.questions) { question in
                        HStack {
                        if isDeleted  && (viewModel.user?.firstName ?? "" == question.createur){
                            Button(action: {
                                viewModel.deleteQuestion(questionId: question.idQuestion)
                            }) {
                                Image(systemName: "minus.circle")
                            }
                        }
                        NavigationLink(destination: QuestionDetailView(question: question, modelView: viewModel)) {
                                AvatarForumView(createur: question.createur)
                                VStack(alignment: .leading, spacing: 8) {
                                    Text(question.objet)
                                        .font(.title2)
                                        
                                    Text(question.question)
                                        .font(.headline)
                                        .foregroundColor(Color("DarkBlue"))
                                    Text("Par \(question.createur)")
                                        .font(.subheadline)
                                        .italic()
                                }
                            }
                        }
                    }
                } else {
                    Text("Aucune question disponible.")
                }
            }
            .onAppear {
                viewModel.fetchQuestion()
        }
        }
    }
}

struct ForumView_Previews: PreviewProvider {
    static var previews: some View {
        ForumView()
    }
}


struct AvatarForumView: View {
    var createur: String

    var body: some View {
        ZStack {
            Circle()
                .fill(Color("Vert"))
                .frame(width: 30, height: 30)
            Text(createur.prefix(1).uppercased())
                .foregroundColor(.white)
                .bold()
        }
    }
}

