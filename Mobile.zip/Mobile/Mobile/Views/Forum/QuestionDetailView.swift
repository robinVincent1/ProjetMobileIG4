import SwiftUI

struct QuestionDetailView: View {
    var question: Question
    @State private var responseText: String = ""
    var modelView: ForumViewModel

    var body: some View {
        VStack {
            Divider()

            Text(question.question)
                .padding()
                .bold()
                .font(.title2)
                .foregroundColor(Color("DarkBlue"))

            Divider()
            
            Text("Début de la conversation")
                .italic()
                .foregroundStyle(Color.gray)

            VStack(alignment: .leading) {
                ScrollView {
                    ForEach(question.idReponse.reversed(), id: \.idReponse) { reponse in
                        HStack {
                            if question.createur == modelView.user?.firstName ?? "" {
                                Button(action: {
                                    modelView.deleteReponse(reponseId: reponse.idReponse)
                                }) {
                                    Image(systemName: "minus.circle")
                                }
                            }
                            VStack {
                                AvatarForumView(createur: reponse.createur)
                                Text(reponse.createur)
                                    .italic()
                            }
                            VStack(alignment: .leading, spacing: 10) {
                                Text(reponse.reponse)
                                    .padding()
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(8)
                                    .frame(maxWidth: .infinity, alignment: .leading) // Alignement à gauche
                            }
                            .padding(.horizontal)
                        }
                    }
                    
                    VStack{
                        TextField("Votre réponse", text: $responseText)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                        
                        Button(action: {
                            // Action pour envoyer la réponse
                            modelView.sendReponse(createur: modelView.user?.firstName ?? "", responseText: responseText, questionId: question.idQuestion)
                            modelView.fetchQuestion()
                        }) {
                            Text("Répondre")
                            Image(systemName: "rectangle.and.pencil.and.ellipsis")
                        }
                        .padding()
                        .foregroundColor(.white)
                        .background(Color("Vert"))
                        .cornerRadius(8)
                    }
                }
            }

            Spacer()
        }
        .padding()
    }
}
