//
//  MobileApp.swift
//  Mobile
//
//  Created by Robin Vincent on 12/03/2024.
//

import SwiftUI

@main
struct MobileApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
