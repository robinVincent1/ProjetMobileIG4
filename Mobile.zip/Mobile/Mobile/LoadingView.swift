import SwiftUI

struct LoadinggView: View {
    var body: some View {
        VStack(spacing: 50) {
            SkeletonCellView()
            SkeletonCellView()
            SkeletonCellView()
            SkeletonCellView()
        }
        .blinking(duration: 0.75)
        .padding(EdgeInsets(top: 0, leading: 16, bottom: 0, trailing: 16))
    }
}

struct SkeletonCellView: View {
    let primaryColor = Color(.init(gray: 0.9, alpha: 1.0))
    let secondaryColor  = Color(.init(gray: 0.8, alpha: 1.0))
    
    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            secondaryColor
                .frame(width: 116, height: 116)

            VStack(alignment: .leading, spacing: 6) {
                secondaryColor
                    .frame(height: 20)
                
                primaryColor
                    .frame(height: 20)
                
                primaryColor
                    .frame(width: 94, height: 15)
            }
        }
    }
}

#Preview {
    LoadinggView()
}
